# Design Decisions

This document explains the significant trade-offs made building this
system, and what would change first if it needed to scale beyond a
reference implementation.

## 1. Atomic claiming

**Decision:** claim jobs inside a `BEGIN IMMEDIATE` SQLite transaction:
select candidates, then `UPDATE ... WHERE status IN ('queued','scheduled','retrying')`
re-checking the status in the same transaction.

**Why it's correct:** `BEGIN IMMEDIATE` acquires SQLite's write lock
immediately rather than lazily, which serializes all writers — two
"concurrent" calls to `claimJobs` from different workers cannot
actually interleave their statements; one transaction fully completes
(commit or rollback) before the other's `BEGIN IMMEDIATE` can proceed.
Combined with the `WHERE status IN (...)` re-check on the `UPDATE`,
this means it's structurally impossible for two workers to both
successfully flip the same job to `claimed` — the second `UPDATE`
simply affects 0 rows for any job the first one already took. This is
verified directly in `tests/claim.test.js`.

**Trade-off:** SQLite's single-writer model means claims are globally
serialized, not just serialized *per queue*. For the load this system
targets (a small-to-medium number of workers, sub-millisecond claim
transactions), that serialization is not a bottleneck — but it is a
ceiling. In **Postgres**, the equivalent (and better-scaling) approach is:
```sql
SELECT id FROM jobs
WHERE status IN ('queued','scheduled','retrying') AND run_at <= now()
ORDER BY priority DESC, run_at ASC
LIMIT $1
FOR UPDATE SKIP LOCKED;
```
`SKIP LOCKED` lets N workers claim from the same queue truly
concurrently — each one skips rows already locked by another
in-flight claim, instead of blocking behind a single global write
lock. Porting this system to Postgres is a same-shaped, contained
change: `db/index.js`'s transaction wrapper and `jobService.claimJobs`'s
SQL are the only places that need to change; the rest of the codebase
talks to the DB through those two seams.

## 2. Why SQLite (via `node:sqlite`) instead of Postgres for this submission

This is the single biggest deviation from what a production system
would use, so it's worth being explicit about why:

- **Zero external dependencies to run the grader's evaluation.** Node
  22's built-in `node:sqlite` module needs no `npm install` of a native
  binding, no separate database server, no connection string — clone,
  `npm install`, `npm start`. Grading this assignment shouldn't require
  standing up Postgres.
- The schema (see `ER_DIAGRAM.md`) is written to be **directly portable**:
  every SQLite-specific detail is isolated and called out in a comment
  at the top of `schema.sql`, and the one behavioral difference that
  matters for correctness (`SKIP LOCKED` vs. `BEGIN IMMEDIATE`) is
  isolated to `jobService.claimJobs`.
- **What you lose** moving to SQLite: true concurrent writers (see §1),
  and the richer indexing/partitioning options Postgres has for a
  `jobs` table with millions of rows. For a real production deployment,
  Postgres (or MySQL) is the right choice and the migration path above
  is intentionally short.

## 3. Retry strategy: backoff + full jitter, computed server-side

**Decision:** each job snapshots its own `retry_strategy` /
`base_delay_ms` / `max_delay_ms` / `max_attempts` at creation time
(from the queue's default retry policy, or per-job overrides). On
failure, the server — not the worker — computes the next `run_at`
using one of three strategies (`fixed`, `linear`, `exponential`), then
applies **full jitter**: the final delay is a uniformly random value in
`[0, computed_delay]`.

**Why:** Computing backoff server-side (rather than trusting a worker
to self-schedule its retry) keeps the source of truth in one place and
makes the behavior auditable independent of which worker handled which
attempt. Full jitter (the AWS Architecture Blog's recommended
"Exponential Backoff and Jitter" approach) exists specifically to avoid
a thundering herd: if 500 jobs fail at the same instant because a
downstream dependency went down, naive exponential backoff would have
all 500 retry at the exact same moment again. Jitter spreads them out.

**Trade-off:** full jitter means a specific job's *next* retry time is
not predictable in advance (only its upper bound is) — acceptable here
since nothing in this system needs to schedule around a job's retry
time in advance.

## 4. Dead Letter Queue as a separate table, not a `jobs.status` value

**Decision:** `dead_letter` is a valid `jobs.status`, but a permanently
failed job also gets a row written to a dedicated `dead_letter_queue`
table with a payload snapshot and failure reason.

**Why:** Keeps the two use cases cleanly separated: `jobs` is the
*live/working set* that the claim query scans continuously, and
`dead_letter_queue` is an *inspection/audit log* that dashboard views
read from without touching the hot path's index. It also naturally
supports "what did the payload look like at the moment it died" even if
retry logic later mutated the job row for other reasons.

## 5. Idempotency

**Decision:** jobs may optionally carry an `idempotency_key`, unique
per queue. Creating a job with a key that already exists on that queue
returns the *original* job instead of inserting a duplicate.

**Why:** The most common real-world failure mode for job schedulers is
a client retrying a "create job" API call after a network timeout, not
knowing whether the first call succeeded. Idempotency keys make that
retry safe by construction rather than relying on the client to dedupe.
Recurring jobs get this for free: each materialized instance is keyed
`recurring:<definition_id>:<slot_timestamp>`, so even if the scheduler
tick somehow ran twice for the same due slot (e.g. after a crash
mid-tick), the second run is a no-op.

## 6. Batches as a first-class grouping, not a client-side convention

**Decision:** a `batches` row aggregates `total_jobs` /
`completed_jobs` / `failed_jobs` / rollup `status`, updated
transactionally every time a member job completes or fails.

**Trade-off:** this couples `jobService.markCompleted` /
`markFailed` to batch bookkeeping. The alternative — computing batch
progress with a `COUNT(*) ... WHERE batch_id = ?` query on demand — was
rejected because it would require a full table scan (or at least an
index scan over every job in the batch) on every dashboard poll, versus
an O(1) counter increment on the write path.

## 7. Polling over WebSockets for the dashboard

**Decision:** the dashboard polls (3–4s intervals depending on the
view) rather than subscribing to a WebSocket/SSE stream.

**Why:** Polling is simpler to reason about, works identically whether
the API has 1 replica or 10 behind a load balancer (no sticky sessions
or a pub/sub fan-out layer needed), and 3–4 seconds of staleness is
acceptable for an operations dashboard, not a real-time chat app.

**Trade-off:** this is the most obvious "next feature" if this were
going further — WebSocket push (listed as a bonus feature in the
brief) would reduce both latency and the steady background request
volume against the API as the number of open dashboard tabs grows.

## 8. RBAC scope

**Decision:** implemented organization-level roles (`owner`, `admin`,
`member`, `viewer`) via `org_members`, enforced today only on the
"rotate API key" action.

**Why this scope:** demonstrates the schema and middleware pattern
(`requireRole(...)`) end-to-end without over-building policy checks for
every single endpoint before the core scheduler logic was proven out.
Extending enforcement to more actions (e.g. `viewer` can't pause a
queue or create jobs) is additive — the `req.membership` object is
already available on every project-scoped request.

## 9. What's explicitly out of scope for this submission

- **Workflow dependencies** (job B waits on job A) — bonus feature, not implemented.
  Would need a `job_dependencies` join table and a claim-query change to also
  check `NOT EXISTS (unfinished dependency)`.
- **Rate limiting** — not implemented at the API layer. Would sit as
  Express middleware in front of the job-creation and claim endpoints.
- **Queue sharding / distributed locking beyond the claim mechanism** —
  the single-database design in §2 is the current scaling ceiling;
  sharding would mean partitioning queues across multiple database
  instances, which is a significant architecture change, not a
  incremental one.
- **Heartbeat/log retention** — `worker_heartbeats` and `job_logs`
  grow unboundedly; a scheduled cleanup job is a known gap (noted in
  `ER_DIAGRAM.md`).
