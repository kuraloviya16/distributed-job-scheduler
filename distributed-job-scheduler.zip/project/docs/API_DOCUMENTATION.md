# API Documentation

Base URL (local dev): `http://localhost:4000`

## Authentication

Two schemes are used, for two different kinds of caller:

| Scheme | Header | Used by |
|---|---|---|
| **JWT bearer** | `Authorization: Bearer <token>` | Human users of the dashboard (login/register) |
| **Project API key** | `X-API-Key: <key>` | Worker processes and external services submitting/executing jobs |

All error responses share one shape:
```json
{ "error": { "message": "human-readable description", "details": "optional" } }
```

---

## Auth

### `POST /api/auth/register`
Creates a user, an organization (owned by that user), and an
`owner`-role membership in one transaction.

**Body**
```json
{ "email": "a@b.com", "password": "min 8 chars", "name": "Ada", "orgName": "optional" }
```
**201**
```json
{ "token": "...", "user": { "id": 1, "email": "a@b.com", "name": "Ada" }, "organizationId": 1 }
```

### `POST /api/auth/login`
**Body:** `{ "email": "...", "password": "..." }`
**200:** `{ "token": "...", "user": { "id", "email", "name" } }`

---

## Projects  *(JWT required)*

### `GET /api/projects`
Lists all projects the authenticated user's organizations belong to.

### `POST /api/projects`
**Body:** `{ "name": "...", "description": "optional", "orgId": "optional, defaults to your first org" }`
**201:** the created project, including its `api_key`.

### `GET /api/projects/:projectId`
Returns one project. Requires the user's org to own it (403 otherwise).

### `POST /api/projects/:projectId/rotate-key`
Requires role `owner` or `admin`. Rotates and returns the project's `api_key`.

---

## Queues  *(JWT required, nested under a project)*

### `GET /api/projects/:projectId/queues`
### `POST /api/projects/:projectId/queues`
**Body**
```json
{
  "name": "emails",
  "priority": 10,
  "concurrencyLimit": 5,
  "retryPolicy": { "strategy": "exponential", "baseDelayMs": 1000, "maxDelayMs": 300000, "maxAttempts": 5, "jitter": true }
}
```
`retryPolicy` is optional; omit it to use the built-in defaults
(exponential, 1s base, 5 attempts).

### `GET /api/projects/:projectId/queues/:queueId`
### `PATCH /api/projects/:projectId/queues/:queueId`
**Body (all optional):** `{ "priority": 5, "concurrencyLimit": 10, "isPaused": false }`

### `POST /api/projects/:projectId/queues/:queueId/pause`
### `POST /api/projects/:projectId/queues/:queueId/resume`
Paused queues are skipped by the worker claim query — jobs stay queued but idle.

### `GET /api/projects/:projectId/queues/:queueId/stats`
Returns per-status job counts, currently-running count vs. concurrency
limit, jobs completed in the last hour, and average execution duration.

---

## Jobs  *(JWT required)*

### `POST /api/projects/:projectId/queues/:queueId/jobs`
The single endpoint for all five submission modes.

**Common body shape**
```json
{ "type": "send_email", "payload": { "...": "..." }, "mode": "immediate", "options": { } }
```

| `mode` | Required `options` | Effect |
|---|---|---|
| `immediate` (default) | — | `run_at = now`, `status = 'queued'` |
| `delayed` | `delaySeconds` | `run_at = now + delaySeconds`, `status = 'scheduled'` |
| `scheduled` | `runAt` (ISO 8601) | `run_at = runAt`, `status = 'scheduled'` |
| `recurring` | `name`, `cronExpression`, optional `timezone` | Creates a `recurring_jobs` definition; the scheduler tick materializes concrete job rows every time the cron fires. Returns the recurring job definition, not a job. |
| `batch` | `items` (non-empty array), optional `name` | Creates a `batches` row plus one job per array element (each element becomes that job's `payload`). Returns the batch. |

Other optional `options` fields (any mode except recurring/batch):
`priority`, `maxAttempts`, `retryStrategy`, `baseDelayMs`, `maxDelayMs`,
`idempotencyKey` (creating a job twice with the same key on the same
queue returns the original job instead of creating a duplicate).

### `GET /api/projects/:projectId/queues/:queueId/jobs`
Query params: `status`, `type`, `page`, `limit` (max 100, default 20).
**200:** `{ "data": [...], "pagination": { "total", "limit", "offset" } }`

### `GET /api/jobs/:jobId`
### `GET /api/jobs/:jobId/logs`
### `GET /api/jobs/:jobId/executions`
Full per-attempt history: worker id, status, duration, error message.

### `POST /api/jobs/:jobId/retry`
Only valid for jobs currently in `dead_letter`. Resets
`attempt_count = 0` and `status = 'queued'`.

### `POST /api/jobs/:jobId/cancel`
Valid for any job not already `completed`/`dead_letter`/`cancelled`.

---

## Workers

### `GET /api/workers`  *(JWT required)*
Dashboard view of every registered worker, with `is_stale` computed
server-side (`1` if no heartbeat in the last 30 seconds while not
already `offline`).

The remaining worker endpoints use **project API key** auth
(`X-API-Key`), since a worker process is not a logged-in human:

### `POST /api/workers/register`
**Body:** `{ "id": "host:pid:rand", "hostname": "...", "pid": 123, "concurrency": 4 }`

### `POST /api/workers/:workerId/heartbeat`
**Body:** `{ "activeJobs": 2 }`

### `POST /api/workers/:workerId/claim`
The atomic claim endpoint. **Body:** `{ "maxJobs": 4, "queueIds": [1,2] }`
(`queueIds` optional — omit to consider all queues in the authenticating project).
**200:** `{ "data": [ <job>, ... ] }` — may return fewer than `maxJobs`, or `[]`.

### `POST /api/workers/:workerId/jobs/:jobId/running`
Marks the job `running`, increments `attempt_count`, opens a
`job_executions` row.

### `POST /api/workers/:workerId/jobs/:jobId/complete`
**Body:** `{ "result": { "...": "..." } }` (optional, stored on the execution row).

### `POST /api/workers/:workerId/jobs/:jobId/fail`
**Body:** `{ "error": "message" }` (required). Triggers retry-with-backoff
or dead-lettering depending on remaining attempts.

### `POST /api/workers/:workerId/drain`
### `POST /api/workers/:workerId/offline`
Lifecycle markers called by the worker process itself during graceful shutdown.

---

## Metrics  *(JWT required)*

### `GET /api/projects/:projectId/metrics`
```json
{
  "jobCounts": { "completed": 120, "retrying": 3, "dead_letter": 1 },
  "workers": { "online": 2, "draining": 0, "offline": 1 },
  "throughputByHour": [ { "hour": "2026-07-04 09:00", "completed": 42 } ],
  "deadLetterCount": 1,
  "avgDurationMs": 812.4,
  "failureRate": { "completed": 120, "dead_lettered": 1 }
}
```

---

## Dead Letter Queue  *(JWT required)*

### `GET /api/projects/:projectId/dead-letter-queue`
Query params: `page`, `limit`. Returns permanently-failed jobs with the
queue name joined in, the failure reason, a payload snapshot, and the
attempt count at time of failure. To retry one, use
`POST /api/jobs/:jobId/retry`.

---

## Pagination

Any list endpoint that supports it accepts `?page=1&limit=20` (limit
capped at 100) and returns `{ "data": [...], "pagination": { "total", "limit", "offset" } }`.

## Error codes

| Status | Meaning |
|---|---|
| 400 | Validation failure (missing/invalid field) |
| 401 | Missing/invalid JWT or API key |
| 403 | Authenticated, but not authorized for this resource (wrong org, wrong role) |
| 404 | Resource not found |
| 409 | Conflict (e.g. duplicate email on register) |
| 500 | Unhandled server error (logged server-side; message is generic to avoid leaking internals) |
