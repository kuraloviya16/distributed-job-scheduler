# Architecture

## 1. System overview

The platform is a **pull-based distributed job scheduler**: a stateless
REST API backed by a relational database is the single source of truth,
and any number of independent worker processes poll that database,
atomically claim work, execute it, and report back. There is no message
broker in the reference implementation — the database *is* the queue.
This is a deliberate simplification explained in
[`DESIGN_DECISIONS.md`](./DESIGN_DECISIONS.md); the interfaces are
shaped so a broker (Redis Streams, SQS, Kafka) could be substituted in
without changing the worker or dashboard contracts.

```mermaid
flowchart LR
    subgraph Clients
        UI[React Dashboard]
        EXT[External services\nvia REST API]
    end

    subgraph API["API Server (Express)"]
        AUTH[Auth\nJWT + API Key]
        PROJ[Projects / Queues]
        JOBS[Job Service\natomic claim, lifecycle]
        SCHED[Scheduler Tick\ncron materializer]
        MET[Metrics Service]
    end

    DB[(Relational DB\nSQLite via node:sqlite\nPostgres-portable schema)]

    subgraph Workers["Worker Processes (N instances)"]
        W1[Worker 1]
        W2[Worker 2]
        W3[Worker N]
    end

    UI -- HTTPS/JSON --> API
    EXT -- HTTPS/JSON + API key --> API
    API <--> DB
    SCHED -- "every 5s: materialize\ndue recurring jobs" --> DB

    W1 -- "poll & claim (API key)" --> API
    W2 -- "poll & claim (API key)" --> API
    W3 -- "poll & claim (API key)" --> API
    W1 -. "heartbeat every 10s" .-> API
    W2 -. "heartbeat every 10s" .-> API
    W3 -. "heartbeat every 10s" .-> API
```

## 2. Components

| Component | Responsibility |
|---|---|
| **API server** (`backend/src/server.js`) | Express app exposing REST endpoints for auth, projects, queues, jobs, workers, metrics, and the dead letter queue. Also runs the in-process scheduler tick. |
| **Job service** (`services/jobService.js`) | The correctness-critical module: job creation for all five submission modes, atomic claiming, and the retry/DLQ state machine. |
| **Scheduler tick** (`services/schedulerService.js`) | Runs every 5s. Finds `recurring_jobs` definitions whose `next_run_at` has elapsed, materializes a concrete `jobs` row (idempotently, keyed by `recurring:<id>:<slot>`), and computes the next cron occurrence. |
| **Worker process** (`worker/workerProcess.js`) | A standalone Node.js process (run as many as you like, on as many machines as you like). Polls `/api/workers/:id/claim`, executes the job via a pluggable handler registry, reports `running` → `complete`/`fail`, sends periodic heartbeats, and drains in-flight jobs on `SIGTERM`/`SIGINT` before exiting. |
| **Job handler registry** (`worker/jobHandlers.js`) | Maps a job's `type` string to an async function. Ships with `echo`, `sleep`, `http_request`, `send_email` (stub), and `fail_test` (for demoing retries). Adding a new job type is a one-line `registerHandler` call — no server changes needed. |
| **Dashboard** (`frontend/`) | React SPA. Polls the API every 3–4s per view for live-ish updates (see trade-off discussion in Design Decisions re: polling vs. WebSockets). |

## 3. Request/data flow for one job

1. **Submit** — A client (dashboard or external service with a project API key) calls
   `POST /api/projects/:id/queues/:id/jobs` with a `mode` (`immediate` | `delayed` |
   `scheduled` | `recurring` | `batch`). The job service resolves the queue's
   default retry policy, computes `run_at`, and inserts a row with
   `status = 'queued'` (or `'scheduled'` for delayed/scheduled/recurring-derived jobs).
2. **Poll & claim** — A worker calls `POST /api/workers/:workerId/claim`. Inside a
   single `BEGIN IMMEDIATE` transaction, the server selects the highest-priority
   eligible jobs (`status IN ('queued','scheduled','retrying')` and `run_at <= now`)
   across the queues the worker is willing to serve, then flips their status to
   `claimed` with a re-checked `UPDATE ... WHERE status IN (...)`. See
   [Design Decisions §1](./DESIGN_DECISIONS.md#1-atomic-claiming) for why this
   guarantees exactly one worker wins each job.
3. **Execute** — The worker reports `running` (which also increments `attempt_count`
   and opens a `job_executions` row), runs the handler for the job's `type`, and
   reports the outcome.
4. **Complete** — On success, the job and its execution row are marked `completed`
   with a computed `duration_ms`. If the job belongs to a batch, the batch's
   counters are updated and its aggregate status is recomputed.
5. **Fail → retry or dead-letter** — On failure, the server decides whether
   `attempt_count >= max_attempts`. If not, it computes a backoff delay (fixed /
   linear / exponential, with optional full jitter) and sets `status = 'retrying'`
   with a future `run_at` — the *same* claim query will pick it back up once that
   time passes. If attempts are exhausted, the job moves to `dead_letter` and a
   `dead_letter_queue` row is written with a snapshot of the payload and reason.

## 4. Job lifecycle state machine

```mermaid
stateDiagram-v2
    [*] --> queued: immediate
    [*] --> scheduled: delayed / scheduled / recurring tick
    scheduled --> claimed: run_at elapsed, worker claims
    queued --> claimed: worker claims
    claimed --> running: worker reports start
    running --> completed: handler resolves
    running --> retrying: handler throws,\nattempts remain
    running --> dead_letter: handler throws,\nattempts exhausted
    retrying --> claimed: run_at elapsed\n(backoff done)
    dead_letter --> queued: manual retry\n(POST /jobs/:id/retry)
    queued --> cancelled: POST /jobs/:id/cancel
    scheduled --> cancelled: POST /jobs/:id/cancel
    claimed --> cancelled: POST /jobs/:id/cancel
    completed --> [*]
    cancelled --> [*]
```

## 5. Concurrency & multi-worker model

Every worker is a peer — there is no leader/follower distinction. Each
worker independently polls, claims up to its free `concurrency` slots,
and executes jobs with plain JS async concurrency (bounded by an
in-memory `activeCount` counter, not OS threads/processes). Running
more workers, or the same worker with higher `WORKER_CONCURRENCY`,
scales throughput horizontally with no coordination needed beyond the
database transaction that makes claiming atomic.

## 6. Deployment shape (reference)

```
┌────────────────────┐      ┌────────────────────┐
│   nginx / CDN       │      │   Postgres (prod)   │
│  serves frontend/dist│      │  (swap in for SQLite)│
└─────────┬──────────┘      └─────────┬──────────┘
          │                            │
          ▼                            ▼
   ┌─────────────┐    HTTPS    ┌───────────────┐
   │   Browser   │ ──────────► │   API server   │
   └─────────────┘             │ (N replicas,   │
                                │  stateless)    │
                                └───────┬────────┘
                                        │
                     ┌──────────────────┼──────────────────┐
                     ▼                  ▼                  ▼
               ┌───────────┐      ┌───────────┐      ┌───────────┐
               │ Worker (VM│      │ Worker (VM│      │ Worker (k8s│
               │  or pod)  │      │  or pod)  │      │   Job)     │
               └───────────┘      └───────────┘      └───────────┘
```

The API server is stateless (all state lives in the DB), so it can run
as multiple replicas behind a load balancer. Workers are just another
kind of client of the API and can be scaled independently, including on
different hosts than the API itself.
