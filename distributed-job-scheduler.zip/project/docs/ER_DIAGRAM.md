# Entity–Relationship Diagram

Full DDL: [`backend/src/db/schema.sql`](../backend/src/db/schema.sql).
Written for SQLite (via Node's built-in `node:sqlite`) but designed to
port to Postgres with only the notes at the top of that file (mainly:
`AUTOINCREMENT` → `BIGSERIAL`, `TEXT` JSON columns → `JSONB`, `DATETIME`
→ `TIMESTAMPTZ`).

```mermaid
erDiagram
    USERS ||--o{ ORGANIZATIONS : owns
    USERS ||--o{ ORG_MEMBERS : "is a"
    ORGANIZATIONS ||--o{ ORG_MEMBERS : has
    ORGANIZATIONS ||--o{ PROJECTS : has
    PROJECTS ||--o{ RETRY_POLICIES : defines
    PROJECTS ||--o{ QUEUES : has
    RETRY_POLICIES ||--o{ QUEUES : "default for"
    QUEUES ||--o{ JOBS : contains
    QUEUES ||--o{ RECURRING_JOBS : defines
    QUEUES ||--o{ BATCHES : contains
    RECURRING_JOBS ||--o{ JOBS : materializes
    BATCHES ||--o{ JOBS : groups
    JOBS ||--o{ JOB_EXECUTIONS : "attempt history"
    JOBS ||--o{ JOB_LOGS : logs
    JOB_EXECUTIONS ||--o{ JOB_LOGS : "scoped to"
    JOBS ||--o| DEAD_LETTER_QUEUE : "terminal failure"
    QUEUES ||--o{ DEAD_LETTER_QUEUE : contains
    WORKERS ||--o{ WORKER_HEARTBEATS : reports

    USERS {
        int id PK
        text email UK
        text password_hash
        text name
    }
    ORGANIZATIONS {
        int id PK
        text name
        int owner_id FK
    }
    ORG_MEMBERS {
        int org_id PK_FK
        int user_id PK_FK
        text role "owner|admin|member|viewer"
    }
    PROJECTS {
        int id PK
        int org_id FK
        text name
        text api_key UK
    }
    RETRY_POLICIES {
        int id PK
        int project_id FK
        text strategy "fixed|linear|exponential"
        int base_delay_ms
        int max_delay_ms
        int max_attempts
        int jitter
    }
    QUEUES {
        int id PK
        int project_id FK
        text name
        int priority
        int concurrency_limit
        int retry_policy_id FK
        int is_paused
    }
    BATCHES {
        int id PK
        int queue_id FK
        int total_jobs
        int completed_jobs
        int failed_jobs
        text status
    }
    RECURRING_JOBS {
        int id PK
        int queue_id FK
        text cron_expression
        text next_run_at
        text last_run_at
        int is_active
    }
    JOBS {
        int id PK
        int queue_id FK
        int batch_id FK
        int recurring_job_id FK
        text type
        text payload "JSON"
        text status
        int priority
        int attempt_count
        int max_attempts
        text retry_strategy
        text run_at
        text idempotency_key UK_per_queue
        text claimed_by
    }
    JOB_EXECUTIONS {
        int id PK
        int job_id FK
        int attempt_number
        text worker_id
        text status
        int duration_ms
        text error_message
    }
    JOB_LOGS {
        int id PK
        int job_id FK
        int execution_id FK
        text level
        text message
    }
    WORKERS {
        text id PK
        text hostname
        int pid
        text status "online|draining|offline"
        int concurrency
        int active_jobs
    }
    WORKER_HEARTBEATS {
        int id PK
        text worker_id FK
        int active_jobs
        text created_at
    }
    DEAD_LETTER_QUEUE {
        int id PK
        int job_id FK
        int queue_id FK
        text reason
        text payload_snapshot
        int attempt_count
    }
```

## Design rationale

### Normalization
The schema is in **3NF**. Retry policy is factored out of `queues` into
its own `retry_policies` table because policies are named/reusable
independent of any one queue, but — critically — a **job snapshots the
effective retry fields (`retry_strategy`, `base_delay_ms`,
`max_delay_ms`, `max_attempts`) at creation time** rather than joining
to `retry_policies` at read time. This is a deliberate, small
denormalization: if someone edits a retry policy, jobs already in
flight must keep behaving the way they were told they would when they
were created. Recomputing backoff off a policy that changed underneath
a job would violate the principle of least surprise for anyone
debugging a specific job's history.

### Keys
- Every table has a surrogate integer primary key except `org_members`
  (composite PK `(org_id, user_id)` — a pure join table with no
  independent identity) and `workers` (natural key: a worker generates
  its own id as `hostname:pid:random`, which is also globally unique
  and human-readable in logs).
- Foreign keys use `ON DELETE CASCADE` almost everywhere (deleting a
  project should delete its queues, jobs, executions, logs — nothing
  should be "orphaned but still there"), except: `queues.retry_policy_id`
  is `ON DELETE SET NULL` (a queue should survive its policy being
  deleted, falling back to defaults), and `jobs.batch_id` /
  `jobs.recurring_job_id` are also `SET NULL` (a job is a durable
  record of work done; its grouping context disappearing shouldn't
  delete the job itself).

### Indexes and the hot path
The single query that matters most for correctness *and* performance is
the worker polling query — every worker, every ~1 second, asks "what's
the next eligible job?". `idx_jobs_poll` is a composite index on
`(queue_id, status, run_at, priority DESC)` matching exactly that
query's `WHERE`/`ORDER BY` shape, so it can be answered with an index
range scan instead of a table scan even as the `jobs` table grows into
the millions of rows. Secondary indexes exist on `status` alone (for
dashboard aggregate counts), `claimed_by` (worker → its jobs), and
`batch_id` (batch progress rollups).

### Cascading & data lifecycle
Completed/failed jobs are **not** deleted — `job_executions` retains
full attempt history, and `dead_letter_queue` retains a payload
snapshot independent of the live `jobs` row, specifically so that a
retention/cleanup job could later purge old `jobs` rows without losing
the audit trail of what happened. (No such purge job is implemented
here; it's a natural next step flagged in Design Decisions.)

### Performance considerations at scale
- `jobs` is the table under the most write pressure (every claim,
  every state transition is an `UPDATE`). Keeping it narrow — no large
  blobs, `payload` is JSON text but expected to be small — and pushing
  historical detail out to `job_executions`/`job_logs` keeps its
  working set small and cache-friendly.
- The DLQ is a **separate table**, not a `status` value queried out of
  `jobs` in the hot path — this keeps the polling index free of a
  large, rarely-touched partition of permanently-dead rows.
- `worker_heartbeats` is append-only and unbounded; in production this
  would need a retention policy (e.g. a nightly job deleting rows older
  than 7 days) since it grows without bound. Flagged as a known gap.
