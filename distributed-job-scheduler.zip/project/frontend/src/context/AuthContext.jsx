import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api, setToken } from '../api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [currentProjectId, setCurrentProjectId] = useState(
    () => localStorage.getItem('djs_project_id') || null
  );
  const [loading, setLoading] = useState(true);

  const refreshProjects = useCallback(async () => {
    const { data } = await api.listProjects();
    setProjects(data);
    if (data.length > 0 && !currentProjectId) {
      setCurrentProjectId(String(data[0].id));
      localStorage.setItem('djs_project_id', String(data[0].id));
    }
    return data;
  }, [currentProjectId]);

  useEffect(() => {
    const token = localStorage.getItem('djs_token');
    const storedUser = localStorage.getItem('djs_user');
    if (token && storedUser) {
      setUser(JSON.parse(storedUser));
      refreshProjects().finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async (email, password) => {
    const { token, user: u } = await api.login({ email, password });
    setToken(token);
    localStorage.setItem('djs_user', JSON.stringify(u));
    setUser(u);
    await refreshProjects();
  };

  const register = async (form) => {
    const { token, user: u } = await api.register(form);
    setToken(token);
    localStorage.setItem('djs_user', JSON.stringify(u));
    setUser(u);
    await refreshProjects();
  };

  const logout = () => {
    setToken(null);
    localStorage.removeItem('djs_user');
    localStorage.removeItem('djs_project_id');
    setUser(null);
    setProjects([]);
    setCurrentProjectId(null);
  };

  const selectProject = (id) => {
    setCurrentProjectId(String(id));
    localStorage.setItem('djs_project_id', String(id));
  };

  const currentProject = projects.find((p) => String(p.id) === String(currentProjectId)) || null;

  return (
    <AuthContext.Provider
      value={{
        user, projects, currentProject, currentProjectId,
        loading, login, register, logout, selectProject, refreshProjects,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
