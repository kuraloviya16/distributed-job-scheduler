import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';

export default function Settings() {
  const { currentProject, refreshProjects, selectProject } = useAuth();
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [busy, setBusy] = useState(false);

  const createProject = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const { data } = await api.createProject({ name, description });
      await refreshProjects();
      selectProject(data.id);
      setShowCreate(false);
      setName('');
      setDescription('');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const rotate = async () => {
    if (!currentProject) return;
    if (!confirm('Rotate this API key? Any running worker processes will need the new key.')) return;
    try {
      await api.rotateApiKey(currentProject.id);
      await refreshProjects();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Project Settings</h1>
          <div className="page-subtitle">API credentials and project management</div>
        </div>
        <button className="btn primary" onClick={() => setShowCreate(true)}>+ New Project</button>
      </div>

      {error && <div className="error-banner">{error}</div>}

      {currentProject && (
        <div className="panel" style={{ marginBottom: 16 }}>
          <div className="stat-label" style={{ marginBottom: 10 }}>{currentProject.name}</div>
          {currentProject.description && (
            <div className="dim" style={{ marginBottom: 14 }}>{currentProject.description}</div>
          )}

          <div className="field">
            <label>Worker API Key</label>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                readOnly
                value={revealed ? currentProject.api_key : '•'.repeat(40)}
                style={{ flex: 1 }}
              />
              <button type="button" className="btn" onClick={() => setRevealed((r) => !r)}>
                {revealed ? 'Hide' : 'Reveal'}
              </button>
            </div>
          </div>
          <div className="dim" style={{ fontSize: 12.5, marginBottom: 14 }}>
            Paste this into the backend's <span className="mono">.env</span> as <span className="mono">WORKER_API_KEY</span>{' '}
            before running <span className="mono">npm run worker</span>.
          </div>

          <button className="btn danger" onClick={rotate}>Rotate API Key</button>
        </div>
      )}

      {showCreate && (
        <div className="modal-backdrop" onClick={() => setShowCreate(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="auth-title" style={{ marginBottom: 16 }}>New Project</div>
            <form onSubmit={createProject}>
              <div className="field">
                <label>Name</label>
                <input value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div className="field">
                <label>Description</label>
                <textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} />
              </div>
              <div className="btn-row">
                <button type="button" className="btn" onClick={() => setShowCreate(false)}>Cancel</button>
                <button type="submit" className="btn primary" disabled={busy}>
                  {busy ? 'Creating…' : 'Create Project'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
