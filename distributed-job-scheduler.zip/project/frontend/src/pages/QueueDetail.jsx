import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';
import StatusPill from '../components/StatusPill';

const STATUSES = ['', 'queued', 'scheduled', 'claimed', 'running', 'completed', 'retrying', 'dead_letter', 'cancelled'];
const MODES = ['immediate', 'delayed', 'scheduled', 'recurring', 'batch'];

export default function QueueDetail() {
  const { queueId } = useParams();
  const { currentProjectId } = useAuth();
  const [queue, setQueue] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [error, setError] = useState('');
  const [showCreate, setShowCreate] = useState(false);

  const load = async () => {
    if (!currentProjectId) return;
    try {
      const [q, j] = await Promise.all([
        api.getQueue(currentProjectId, queueId),
        api.listJobs(currentProjectId, queueId, statusFilter ? { status: statusFilter } : {}),
      ]);
      setQueue(q.data);
      setJobs(j.data);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 4000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProjectId, queueId, statusFilter]);

  if (!currentProjectId) return null;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">{queue?.name || 'Queue'}</h1>
          <div className="page-subtitle">
            priority {queue?.priority} · concurrency limit {queue?.concurrency_limit}
            {queue?.is_paused ? ' · paused' : ''}
          </div>
        </div>
        <button className="btn primary" onClick={() => setShowCreate(true)}>+ Submit Job</button>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="panel" style={{ marginBottom: 14 }}>
        <div className="field" style={{ marginBottom: 0, maxWidth: 220 }}>
          <label>Filter by status</label>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            {STATUSES.map((s) => <option key={s} value={s}>{s || 'All statuses'}</option>)}
          </select>
        </div>
      </div>

      <div className="panel">
        {jobs.length === 0 ? (
          <div className="empty-state">No jobs match this filter.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>ID</th><th>Type</th><th>Status</th><th>Attempt</th><th>Run At</th><th></th></tr>
            </thead>
            <tbody>
              {jobs.map((j) => (
                <tr key={j.id}>
                  <td className="mono">#{j.id}</td>
                  <td>{j.type}</td>
                  <td><StatusPill status={j.status} /></td>
                  <td className="mono">{j.attempt_count}/{j.max_attempts}</td>
                  <td className="dim mono">{j.run_at}</td>
                  <td><Link className="link-muted" to={`/jobs/${j.id}`}>View</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showCreate && (
        <CreateJobModal
          projectId={currentProjectId}
          queueId={queueId}
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); load(); }}
        />
      )}
    </div>
  );
}

function CreateJobModal({ projectId, queueId, onClose, onCreated }) {
  const [mode, setMode] = useState('immediate');
  const [type, setType] = useState('echo');
  const [payload, setPayload] = useState('{}');
  const [delaySeconds, setDelaySeconds] = useState(30);
  const [runAt, setRunAt] = useState('');
  const [cronExpression, setCronExpression] = useState('*/5 * * * *');
  const [recurringName, setRecurringName] = useState('my-recurring-job');
  const [batchItems, setBatchItems] = useState('[{"user": 1}, {"user": 2}]');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      let parsedPayload = {};
      if (mode !== 'batch') {
        parsedPayload = payload.trim() ? JSON.parse(payload) : {};
      }

      const options = {};
      if (mode === 'delayed') options.delaySeconds = Number(delaySeconds);
      if (mode === 'scheduled') options.runAt = new Date(runAt).toISOString();
      if (mode === 'recurring') {
        options.cronExpression = cronExpression;
        options.name = recurringName;
      }
      if (mode === 'batch') {
        options.items = JSON.parse(batchItems);
        options.name = recurringName;
      }

      await api.createJob(projectId, queueId, { type, payload: parsedPayload, mode, options });
      onCreated();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="auth-title" style={{ marginBottom: 16 }}>Submit Job</div>
        {error && <div className="error-banner">{error}</div>}
        <form onSubmit={submit}>
          <div className="field">
            <label>Mode</label>
            <select value={mode} onChange={(e) => setMode(e.target.value)}>
              {MODES.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Job type (handler)</label>
            <input value={type} onChange={(e) => setType(e.target.value)} placeholder="echo, sleep, http_request, send_email, fail_test" required />
          </div>

          {mode !== 'batch' && (
            <div className="field">
              <label>Payload (JSON)</label>
              <textarea rows={3} value={payload} onChange={(e) => setPayload(e.target.value)} />
            </div>
          )}

          {mode === 'delayed' && (
            <div className="field">
              <label>Delay (seconds)</label>
              <input type="number" min={0} value={delaySeconds} onChange={(e) => setDelaySeconds(e.target.value)} />
            </div>
          )}

          {mode === 'scheduled' && (
            <div className="field">
              <label>Run at</label>
              <input type="datetime-local" value={runAt} onChange={(e) => setRunAt(e.target.value)} required />
            </div>
          )}

          {mode === 'recurring' && (
            <>
              <div className="field">
                <label>Recurring job name</label>
                <input value={recurringName} onChange={(e) => setRecurringName(e.target.value)} required />
              </div>
              <div className="field">
                <label>Cron expression</label>
                <input value={cronExpression} onChange={(e) => setCronExpression(e.target.value)} required />
              </div>
            </>
          )}

          {mode === 'batch' && (
            <>
              <div className="field">
                <label>Batch name</label>
                <input value={recurringName} onChange={(e) => setRecurringName(e.target.value)} />
              </div>
              <div className="field">
                <label>Items (JSON array — one job per item)</label>
                <textarea rows={4} value={batchItems} onChange={(e) => setBatchItems(e.target.value)} required />
              </div>
            </>
          )}

          <div className="btn-row" style={{ marginTop: 8 }}>
            <button type="button" className="btn" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn primary" disabled={busy}>
              {busy ? 'Submitting…' : 'Submit Job'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
