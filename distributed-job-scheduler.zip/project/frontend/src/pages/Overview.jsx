import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';
import StatusPill from '../components/StatusPill';

export default function Overview() {
  const { currentProjectId } = useAuth();
  const [metrics, setMetrics] = useState(null);
  const [queues, setQueues] = useState([]);
  const [workers, setWorkers] = useState([]);
  const [error, setError] = useState('');

  const load = async () => {
    if (!currentProjectId) return;
    try {
      const [m, q, w] = await Promise.all([
        api.metrics(currentProjectId),
        api.listQueues(currentProjectId),
        api.listWorkers(),
      ]);
      setMetrics(m.data);
      setQueues(q.data);
      setWorkers(w.data);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 4000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProjectId]);

  if (!currentProjectId) return null;

  const counts = metrics?.jobCounts || {};
  const inFlight = (counts.claimed || 0) + (counts.running || 0);
  const maxPriority = Math.max(1, ...queues.map((q) => q.priority));

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">System Overview</h1>
          <div className="page-subtitle">Live status across all queues, jobs, and workers</div>
        </div>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="grid grid-4" style={{ marginBottom: 20 }}>
        <div className="stat-card">
          <div className="stat-label">In Flight</div>
          <div className="stat-value accent">{inFlight}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Completed</div>
          <div className="stat-value">{counts.completed || 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Retrying</div>
          <div className="stat-value warn">{counts.retrying || 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Dead Letter</div>
          <div className="stat-value bad">{metrics?.deadLetterCount || 0}</div>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginBottom: 20, alignItems: 'start' }}>
        <div className="panel">
          <div className="stat-label" style={{ marginBottom: 12 }}>Queues</div>
          {queues.length === 0 ? (
            <div className="empty-state">No queues yet.</div>
          ) : (
            queues.map((q) => (
              <Link
                key={q.id}
                to={`/queues/${q.id}`}
                style={{ display: 'block', textDecoration: 'none', color: 'inherit', marginBottom: 14 }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span>{q.name}</span>
                  <span className="dim mono">
                    priority {q.priority} · concurrency {q.concurrency_limit}
                    {q.is_paused ? ' · paused' : ''}
                  </span>
                </div>
                <div className="priority-lane">
                  <div
                    className="priority-lane-fill"
                    style={{ width: `${Math.max(6, (q.priority / maxPriority) * 100)}%` }}
                  />
                </div>
              </Link>
            ))
          )}
        </div>

        <div className="panel">
          <div className="stat-label" style={{ marginBottom: 12 }}>Workers</div>
          {workers.length === 0 ? (
            <div className="empty-state">No workers registered. Run <span className="mono">npm run worker</span>.</div>
          ) : (
            <table className="data-table">
              <thead>
                <tr><th>ID</th><th>Status</th><th>Active</th><th>Last Heartbeat</th></tr>
              </thead>
              <tbody>
                {workers.map((w) => (
                  <tr key={w.id}>
                    <td className="mono">{w.id}</td>
                    <td><StatusPill status={w.is_stale ? 'failed' : w.status === 'online' ? 'running' : w.status} /></td>
                    <td>{w.active_jobs}</td>
                    <td className="dim mono">{w.last_heartbeat_at}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="panel">
        <div className="stat-label" style={{ marginBottom: 4 }}>Avg. Job Duration</div>
        <div className="stat-value" style={{ fontSize: 18 }}>
          {metrics?.avgDurationMs ? `${Math.round(metrics.avgDurationMs)} ms` : '—'}
        </div>
      </div>
    </div>
  );
}
