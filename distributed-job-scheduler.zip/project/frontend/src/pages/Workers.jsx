import { useEffect, useState } from 'react';
import { api } from '../api';
import StatusPill from '../components/StatusPill';

export default function Workers() {
  const [workers, setWorkers] = useState([]);
  const [error, setError] = useState('');

  const load = async () => {
    try {
      const { data } = await api.listWorkers();
      setWorkers(data);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 3000);
    return () => clearInterval(id);
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Workers</h1>
          <div className="page-subtitle">Every worker process that has registered against this API, across all projects</div>
        </div>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="panel">
        {workers.length === 0 ? (
          <div className="empty-state">
            No workers registered yet. Start one with <span className="mono">npm run worker</span> from the backend directory.
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Worker ID</th><th>Hostname</th><th>PID</th><th>Status</th>
                <th>Concurrency</th><th>Active Jobs</th><th>Started</th><th>Last Heartbeat</th>
              </tr>
            </thead>
            <tbody>
              {workers.map((w) => (
                <tr key={w.id}>
                  <td className="mono">{w.id}</td>
                  <td>{w.hostname}</td>
                  <td className="mono dim">{w.pid}</td>
                  <td><StatusPill status={w.is_stale ? 'failed' : w.status === 'online' ? 'running' : w.status} /></td>
                  <td className="mono">{w.concurrency}</td>
                  <td className="mono">{w.active_jobs}</td>
                  <td className="dim mono">{w.started_at}</td>
                  <td className="dim mono">{w.last_heartbeat_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
