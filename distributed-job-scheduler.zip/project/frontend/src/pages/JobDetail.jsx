import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api';
import StatusPill from '../components/StatusPill';

export default function JobDetail() {
  const { jobId } = useParams();
  const [job, setJob] = useState(null);
  const [executions, setExecutions] = useState([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const [j, ex] = await Promise.all([api.getJob(jobId), api.jobExecutions(jobId)]);
      setJob(j.data);
      setExecutions(ex.data);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 4000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId]);

  const doRetry = async () => {
    setBusy(true);
    try { await api.retryJob(jobId); await load(); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };

  const doCancel = async () => {
    setBusy(true);
    try { await api.cancelJob(jobId); await load(); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };

  if (!job) return <div className="dim">Loading…</div>;

  let payload = '{}';
  try { payload = JSON.stringify(JSON.parse(job.payload), null, 2); } catch { payload = job.payload; }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Job #{job.id} — {job.type}</h1>
          <div className="page-subtitle">
            <StatusPill status={job.status} /> &nbsp; queue <Link className="link-muted" to={`/queues/${job.queue_id}`}>#{job.queue_id}</Link>
          </div>
        </div>
        <div className="btn-row">
          {job.status === 'dead_letter' && (
            <button className="btn primary" onClick={doRetry} disabled={busy}>Retry Job</button>
          )}
          {!['completed', 'dead_letter', 'cancelled'].includes(job.status) && (
            <button className="btn danger" onClick={doCancel} disabled={busy}>Cancel Job</button>
          )}
        </div>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="grid grid-3" style={{ marginBottom: 16 }}>
        <div className="stat-card">
          <div className="stat-label">Attempts</div>
          <div className="stat-value">{job.attempt_count} / {job.max_attempts}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Retry Strategy</div>
          <div className="stat-value" style={{ fontSize: 16 }}>{job.retry_strategy}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Run At</div>
          <div className="stat-value mono" style={{ fontSize: 14 }}>{job.run_at}</div>
        </div>
      </div>

      {job.last_error && (
        <div className="error-banner">Last error: {job.last_error}</div>
      )}

      <div className="panel" style={{ marginBottom: 16 }}>
        <div className="stat-label" style={{ marginBottom: 8 }}>Payload</div>
        <pre className="mono" style={{ margin: 0, whiteSpace: 'pre-wrap', color: 'var(--text-secondary)' }}>{payload}</pre>
      </div>

      <div className="panel">
        <div className="stat-label" style={{ marginBottom: 12 }}>Execution History</div>
        {executions.length === 0 ? (
          <div className="empty-state">No attempts yet.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Attempt</th><th>Worker</th><th>Status</th><th>Duration</th><th>Error</th></tr>
            </thead>
            <tbody>
              {executions.map((ex) => (
                <tr key={ex.id}>
                  <td className="mono">{ex.attempt_number}</td>
                  <td className="mono dim">{ex.worker_id}</td>
                  <td><StatusPill status={ex.status} /></td>
                  <td className="mono">{ex.duration_ms != null ? `${ex.duration_ms} ms` : '—'}</td>
                  <td className="dim">{ex.error_message || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
