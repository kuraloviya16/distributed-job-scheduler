import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';

export default function DeadLetterQueue() {
  const { currentProjectId } = useAuth();
  const [rows, setRows] = useState([]);
  const [error, setError] = useState('');

  const load = async () => {
    if (!currentProjectId) return;
    try {
      const { data } = await api.deadLetterQueue(currentProjectId, { limit: 50 });
      setRows(data);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => { load(); }, [currentProjectId]);

  if (!currentProjectId) return null;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dead Letter Queue</h1>
          <div className="page-subtitle">Jobs that exhausted every retry attempt and were pulled out of normal flow</div>
        </div>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="panel">
        {rows.length === 0 ? (
          <div className="empty-state">Nothing here — every job either succeeded or is still retrying.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Job</th><th>Queue</th><th>Attempts</th><th>Reason</th><th>Failed At</th></tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td><Link className="link-muted" to={`/jobs/${r.job_id}`}>#{r.job_id}</Link></td>
                  <td>{r.queue_name}</td>
                  <td className="mono">{r.attempt_count}</td>
                  <td className="dim">{r.reason}</td>
                  <td className="dim mono">{r.failed_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
