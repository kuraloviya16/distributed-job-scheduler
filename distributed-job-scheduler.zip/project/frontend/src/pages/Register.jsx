import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', orgName: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await register(form);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="panel auth-card">
        <div className="auth-title">Create account</div>
        <div className="page-subtitle" style={{ marginBottom: 20 }}>
          Sets up your organization and first project
        </div>

        {error && <div className="error-banner">{error}</div>}

        <form onSubmit={submit}>
          <div className="field">
            <label>Name</label>
            <input value={form.name} onChange={update('name')} required />
          </div>
          <div className="field">
            <label>Email</label>
            <input type="email" value={form.email} onChange={update('email')} required />
          </div>
          <div className="field">
            <label>Password (min 8 characters)</label>
            <input type="password" value={form.password} onChange={update('password')} minLength={8} required />
          </div>
          <div className="field">
            <label>Organization name</label>
            <input value={form.orgName} onChange={update('orgName')} placeholder="Optional" />
          </div>
          <button className="btn primary" style={{ width: '100%', justifyContent: 'center' }} disabled={busy}>
            {busy ? 'Creating…' : 'Create account'}
          </button>
        </form>

        <div style={{ marginTop: 16, fontSize: 12.5 }} className="dim">
          Already have an account? <Link className="link-muted" to="/login">Sign in</Link>
        </div>
      </div>
    </div>
  );
}
