import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';

const STRATEGIES = ['exponential', 'linear', 'fixed'];

export default function Queues() {
  const { currentProjectId } = useAuth();
  const [queues, setQueues] = useState([]);
  const [error, setError] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({
    name: '', priority: 0, concurrencyLimit: 5,
    strategy: 'exponential', baseDelayMs: 1000, maxAttempts: 5,
  });

  const load = async () => {
    if (!currentProjectId) return;
    try {
      const { data } = await api.listQueues(currentProjectId);
      setQueues(data);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => { load(); }, [currentProjectId]);

  const createQueue = async (e) => {
    e.preventDefault();
    try {
      await api.createQueue(currentProjectId, {
        name: form.name,
        priority: Number(form.priority),
        concurrencyLimit: Number(form.concurrencyLimit),
        retryPolicy: {
          strategy: form.strategy,
          baseDelayMs: Number(form.baseDelayMs),
          maxAttempts: Number(form.maxAttempts),
        },
      });
      setShowCreate(false);
      setForm({ name: '', priority: 0, concurrencyLimit: 5, strategy: 'exponential', baseDelayMs: 1000, maxAttempts: 5 });
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const togglePause = async (q) => {
    if (q.is_paused) await api.resumeQueue(currentProjectId, q.id);
    else await api.pauseQueue(currentProjectId, q.id);
    load();
  };

  if (!currentProjectId) return null;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Queues</h1>
          <div className="page-subtitle">Priority lanes, concurrency limits, and retry policy per queue</div>
        </div>
        <button className="btn primary" onClick={() => setShowCreate(true)}>+ New Queue</button>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="panel">
        {queues.length === 0 ? (
          <div className="empty-state">No queues yet. Create one to start submitting jobs.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Name</th><th>Priority</th><th>Concurrency</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {queues.map((q) => (
                <tr key={q.id}>
                  <td><Link className="link-muted" to={`/queues/${q.id}`}>{q.name}</Link></td>
                  <td className="mono">{q.priority}</td>
                  <td className="mono">{q.concurrency_limit}</td>
                  <td className="dim">{q.is_paused ? 'paused' : 'active'}</td>
                  <td>
                    <button className="btn" onClick={() => togglePause(q)}>
                      {q.is_paused ? 'Resume' : 'Pause'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showCreate && (
        <div className="modal-backdrop" onClick={() => setShowCreate(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="auth-title" style={{ marginBottom: 16 }}>New Queue</div>
            <form onSubmit={createQueue}>
              <div className="field">
                <label>Name</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div className="field-row">
                <div className="field">
                  <label>Priority</label>
                  <input type="number" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} />
                </div>
                <div className="field">
                  <label>Concurrency limit</label>
                  <input type="number" min={1} value={form.concurrencyLimit} onChange={(e) => setForm({ ...form, concurrencyLimit: e.target.value })} />
                </div>
              </div>
              <div className="field">
                <label>Retry strategy</label>
                <select value={form.strategy} onChange={(e) => setForm({ ...form, strategy: e.target.value })}>
                  {STRATEGIES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="field-row">
                <div className="field">
                  <label>Base delay (ms)</label>
                  <input type="number" value={form.baseDelayMs} onChange={(e) => setForm({ ...form, baseDelayMs: e.target.value })} />
                </div>
                <div className="field">
                  <label>Max attempts</label>
                  <input type="number" min={1} value={form.maxAttempts} onChange={(e) => setForm({ ...form, maxAttempts: e.target.value })} />
                </div>
              </div>
              <div className="btn-row" style={{ marginTop: 8 }}>
                <button type="button" className="btn" onClick={() => setShowCreate(false)}>Cancel</button>
                <button type="submit" className="btn primary">Create Queue</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
