const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000';

function getToken() {
  return localStorage.getItem('djs_token');
}

export function setToken(token) {
  if (token) localStorage.setItem('djs_token', token);
  else localStorage.removeItem('djs_token');
}

async function request(path, { method = 'GET', body } = {}) {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const isJson = res.headers.get('content-type')?.includes('application/json');
  const data = isJson ? await res.json() : null;

  if (!res.ok) {
    const message = data?.error?.message || `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

export const api = {
  register: (body) => request('/api/auth/register', { method: 'POST', body }),
  login: (body) => request('/api/auth/login', { method: 'POST', body }),

  listProjects: () => request('/api/projects'),
  createProject: (body) => request('/api/projects', { method: 'POST', body }),
  getProject: (projectId) => request(`/api/projects/${projectId}`),
  rotateApiKey: (projectId) => request(`/api/projects/${projectId}/rotate-key`, { method: 'POST' }),

  listQueues: (projectId) => request(`/api/projects/${projectId}/queues`),
  createQueue: (projectId, body) =>
    request(`/api/projects/${projectId}/queues`, { method: 'POST', body }),
  getQueue: (projectId, queueId) => request(`/api/projects/${projectId}/queues/${queueId}`),
  updateQueue: (projectId, queueId, body) =>
    request(`/api/projects/${projectId}/queues/${queueId}`, { method: 'PATCH', body }),
  pauseQueue: (projectId, queueId) =>
    request(`/api/projects/${projectId}/queues/${queueId}/pause`, { method: 'POST' }),
  resumeQueue: (projectId, queueId) =>
    request(`/api/projects/${projectId}/queues/${queueId}/resume`, { method: 'POST' }),
  queueStats: (projectId, queueId) =>
    request(`/api/projects/${projectId}/queues/${queueId}/stats`),

  listJobs: (projectId, queueId, params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/api/projects/${projectId}/queues/${queueId}/jobs${qs ? `?${qs}` : ''}`);
  },
  createJob: (projectId, queueId, body) =>
    request(`/api/projects/${projectId}/queues/${queueId}/jobs`, { method: 'POST', body }),
  getJob: (jobId) => request(`/api/jobs/${jobId}`),
  jobLogs: (jobId) => request(`/api/jobs/${jobId}/logs`),
  jobExecutions: (jobId) => request(`/api/jobs/${jobId}/executions`),
  retryJob: (jobId) => request(`/api/jobs/${jobId}/retry`, { method: 'POST' }),
  cancelJob: (jobId) => request(`/api/jobs/${jobId}/cancel`, { method: 'POST' }),

  listWorkers: () => request('/api/workers'),

  metrics: (projectId) => request(`/api/projects/${projectId}/metrics`),

  deadLetterQueue: (projectId, params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/api/projects/${projectId}/dead-letter-queue${qs ? `?${qs}` : ''}`);
  },
};
