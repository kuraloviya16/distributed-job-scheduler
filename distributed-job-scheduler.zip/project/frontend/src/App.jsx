import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Register from './pages/Register';
import Overview from './pages/Overview';
import Queues from './pages/Queues';
import QueueDetail from './pages/QueueDetail';
import JobDetail from './pages/JobDetail';
import Workers from './pages/Workers';
import DeadLetterQueue from './pages/DeadLetterQueue';
import Settings from './pages/Settings';

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div style={{ padding: 40 }} className="dim">Loading…</div>;
  if (!user) return <Navigate to="/login" replace />;
  return <Layout>{children}</Layout>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/" element={<Protected><Overview /></Protected>} />
      <Route path="/queues" element={<Protected><Queues /></Protected>} />
      <Route path="/queues/:queueId" element={<Protected><QueueDetail /></Protected>} />
      <Route path="/jobs/:jobId" element={<Protected><JobDetail /></Protected>} />
      <Route path="/workers" element={<Protected><Workers /></Protected>} />
      <Route path="/dead-letter-queue" element={<Protected><DeadLetterQueue /></Protected>} />
      <Route path="/settings" element={<Protected><Settings /></Protected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
