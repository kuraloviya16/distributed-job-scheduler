import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const NAV = [
  { to: '/', label: 'Overview', end: true },
  { to: '/queues', label: 'Queues' },
  { to: '/workers', label: 'Workers' },
  { to: '/dead-letter-queue', label: 'Dead Letter Queue' },
  { to: '/settings', label: 'Project Settings' },
];

export default function Layout({ children }) {
  const { user, projects, currentProjectId, selectProject, currentProject, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="dot" />
          job-scheduler
        </div>

        {projects.length > 0 && (
          <div style={{ marginBottom: 18 }}>
            <select
              value={currentProjectId || ''}
              onChange={(e) => {
                selectProject(e.target.value);
                navigate('/');
              }}
              style={{
                width: '100%', background: 'var(--bg-inset)', border: '1px solid var(--line)',
                borderRadius: 6, padding: '7px 8px', color: 'var(--text-primary)', fontSize: 12.5,
              }}
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>
        )}

        <div className="nav-section-label">Navigate</div>
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
          >
            {item.label}
          </NavLink>
        ))}

        <div style={{ marginTop: 'auto', paddingTop: 20 }}>
          <div className="dim" style={{ fontSize: 12, padding: '0 10px 8px' }}>
            {user?.name}
          </div>
          <button
            className="nav-link"
            style={{ width: '100%', textAlign: 'left', border: 'none', background: 'transparent' }}
            onClick={() => { logout(); navigate('/login'); }}
          >
            Sign out
          </button>
        </div>
      </aside>

      <main className="main-area">
        {!currentProject && projects.length === 0 ? (
          <div className="empty-state panel">
            No project yet. Create one from Project Settings to get started.
          </div>
        ) : (
          children
        )}
      </main>
    </div>
  );
}
