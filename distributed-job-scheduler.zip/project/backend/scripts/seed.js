'use strict';

require('dotenv').config();
const db = require('../src/db');
const authService = require('../src/services/authService');
const projectService = require('../src/services/projectService');
const queueService = require('../src/services/queueService');
const jobService = require('../src/services/jobService');

async function main() {
  db.init();

  console.log('Seeding demo data...');

  let auth;
  try {
    auth = await authService.register({
      email: 'demo@example.com',
      password: 'password123',
      name: 'Demo User',
      orgName: 'Demo Org',
    });
  } catch (err) {
    console.log('Demo user already exists, logging in instead.');
    auth = await authService.login({ email: 'demo@example.com', password: 'password123' });
  }

  const project = projectService.create({
    orgId: auth.organizationId || 1,
    name: 'Demo Project',
    description: 'Seed data for evaluation',
  });

  const emailQueue = queueService.create({
    projectId: project.id,
    name: 'emails',
    priority: 10,
    concurrencyLimit: 5,
    retryPolicy: { strategy: 'exponential', baseDelayMs: 2000, maxAttempts: 4 },
  });

  const reportsQueue = queueService.create({
    projectId: project.id,
    name: 'reports',
    priority: 5,
    concurrencyLimit: 2,
    retryPolicy: { strategy: 'linear', baseDelayMs: 5000, maxAttempts: 3 },
  });

  jobService.createJob({
    queueId: emailQueue.id,
    type: 'send_email',
    payload: { to: 'user@example.com', subject: 'Welcome!' },
    mode: 'immediate',
  });

  jobService.createJob({
    queueId: emailQueue.id,
    type: 'send_email',
    payload: { to: 'later@example.com', subject: 'Reminder' },
    mode: 'delayed',
    options: { delaySeconds: 30 },
  });

  jobService.createJob({
    queueId: reportsQueue.id,
    type: 'fail_test',
    payload: { message: 'demo failure to show retry/backoff' },
    mode: 'immediate',
  });

  jobService.createJob({
    queueId: reportsQueue.id,
    type: 'echo',
    payload: {},
    mode: 'recurring',
    options: { name: 'nightly-report', cronExpression: '*/1 * * * *' },
  });

  jobService.createJob({
    queueId: emailQueue.id,
    type: 'echo',
    payload: {},
    mode: 'batch',
    options: {
      name: 'digest-batch',
      items: [{ user: 1 }, { user: 2 }, { user: 3 }],
    },
  });

  console.log('\nDone. Demo credentials:');
  console.log('  email:    demo@example.com');
  console.log('  password: password123');
  console.log(`  project:  ${project.name} (id ${project.id})`);
  console.log(`  API key:  ${project.api_key}`);
  console.log('\nPaste that API key into backend/.env as WORKER_API_KEY, then:');
  console.log('  npm start        # in one terminal');
  console.log('  npm run worker   # in another terminal');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
