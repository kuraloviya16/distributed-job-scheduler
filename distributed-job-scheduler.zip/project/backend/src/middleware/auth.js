'use strict';

const jwt = require('jsonwebtoken');
const ApiError = require('../utils/ApiError');
const db = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

/** Requires a valid `Authorization: Bearer <token>` user session. */
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next(new ApiError(401, 'Missing bearer token'));

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    next(new ApiError(401, 'Invalid or expired token'));
  }
}

/**
 * Requires a valid `X-API-Key` header identifying a project. Used for
 * the job-submission endpoints so external services / workers can
 * authenticate without a human user session.
 */
function requireApiKey(req, res, next) {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey) return next(new ApiError(401, 'Missing X-API-Key header'));

  const project = db.get('SELECT * FROM projects WHERE api_key = ?', [apiKey]);
  if (!project) return next(new ApiError(401, 'Invalid API key'));

  req.project = project;
  next();
}

/** Loads :projectId param and verifies the authenticated user's org owns it. */
function loadProject(req, res, next) {
  const project = db.get('SELECT * FROM projects WHERE id = ?', [req.params.projectId]);
  if (!project) return next(new ApiError(404, 'Project not found'));

  const membership = db.get(
    'SELECT * FROM org_members WHERE org_id = ? AND user_id = ?',
    [project.org_id, req.user.sub]
  );
  if (!membership) return next(new ApiError(403, 'Not a member of this project\'s organization'));

  req.project = project;
  req.membership = membership;
  next();
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.membership || !roles.includes(req.membership.role)) {
      return next(new ApiError(403, `Requires one of roles: ${roles.join(', ')}`));
    }
    next();
  };
}

module.exports = { requireAuth, requireApiKey, loadProject, requireRole, JWT_SECRET };
