'use strict';

function ts() {
  return new Date().toISOString();
}

function log(level, msg, meta) {
  const line = { time: ts(), level, msg, ...(meta ? { meta } : {}) };
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(line));
}

module.exports = {
  info: (msg, meta) => log('info', msg, meta),
  warn: (msg, meta) => log('warn', msg, meta),
  error: (msg, meta) => log('error', msg, meta),
  debug: (msg, meta) => {
    if (process.env.DEBUG) log('debug', msg, meta);
  },
};
