'use strict';

/**
 * Compute the delay (ms) before the next retry attempt.
 * `attempt` is the attempt number that just failed (1-indexed).
 * Returns the delay to wait before attempt `attempt + 1`.
 */
function computeBackoffMs({ strategy, baseDelayMs, maxDelayMs, attempt, jitter = true }) {
  let delay;
  switch (strategy) {
    case 'fixed':
      delay = baseDelayMs;
      break;
    case 'linear':
      delay = baseDelayMs * attempt;
      break;
    case 'exponential':
    default:
      delay = baseDelayMs * Math.pow(2, attempt - 1);
      break;
  }

  delay = Math.min(delay, maxDelayMs);

  if (jitter) {
    // Full jitter (AWS-style): random value in [0, delay]. Prevents
    // thundering-herd retries when many jobs fail at the same time.
    delay = Math.floor(Math.random() * delay);
  }

  return Math.max(delay, 0);
}

module.exports = { computeBackoffMs };
