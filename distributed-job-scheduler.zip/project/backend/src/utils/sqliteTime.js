'use strict';

/**
 * SQLite's datetime('now') returns "YYYY-MM-DD HH:MM:SS" (space-separated,
 * no milliseconds, no timezone marker). JS's Date#toISOString() returns
 * "YYYY-MM-DDTHH:MM:SS.sssZ". Storing the latter and comparing it against
 * the former with plain `<=` is a lexicographic string comparison, and
 * 'T' (0x54) sorts *after* ' ' (0x20) — so an ISO string for "right now"
 * incorrectly compares as greater-than datetime('now') for the same
 * instant, making the job polling query silently skip eligible rows.
 * Always pass JS Dates through this before storing them in a DATETIME
 * column that gets compared against datetime('now') in SQL.
 */
function toSqliteDateTime(date) {
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

module.exports = { toSqliteDateTime };
