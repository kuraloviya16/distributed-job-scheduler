'use strict';

function parsePagination(query, { defaultLimit = 20, maxLimit = 100 } = {}) {
  let limit = parseInt(query.limit, 10);
  let page = parseInt(query.page, 10);
  if (!Number.isFinite(limit) || limit <= 0) limit = defaultLimit;
  if (!Number.isFinite(page) || page <= 0) page = 1;
  limit = Math.min(limit, maxLimit);
  const offset = (page - 1) * limit;
  return { limit, page, offset };
}

module.exports = { parsePagination };
