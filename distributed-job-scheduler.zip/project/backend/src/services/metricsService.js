'use strict';

const db = require('../db');

function overview(projectId) {
  const jobCounts = db.all(
    `SELECT j.status, COUNT(*) as count FROM jobs j
     JOIN queues q ON q.id = j.queue_id WHERE q.project_id = ? GROUP BY j.status`,
    [projectId]
  );

  const workerCounts = db.get(
    `SELECT
       SUM(CASE WHEN status = 'online' THEN 1 ELSE 0 END) as online,
       SUM(CASE WHEN status = 'draining' THEN 1 ELSE 0 END) as draining,
       SUM(CASE WHEN status = 'offline' THEN 1 ELSE 0 END) as offline
     FROM workers`
  );

  const throughputByHour = db.all(
    `SELECT strftime('%Y-%m-%d %H:00', completed_at) as hour, COUNT(*) as completed
     FROM jobs j JOIN queues q ON q.id = j.queue_id
     WHERE q.project_id = ? AND j.status = 'completed' AND completed_at >= datetime('now', '-24 hours')
     GROUP BY hour ORDER BY hour ASC`,
    [projectId]
  );

  const dlqCount = db.get(
    `SELECT COUNT(*) as count FROM dead_letter_queue d
     JOIN queues q ON q.id = d.queue_id WHERE q.project_id = ?`,
    [projectId]
  );

  const avgDuration = db.get(
    `SELECT AVG(je.duration_ms) as avg_ms FROM job_executions je
     JOIN jobs j ON j.id = je.job_id JOIN queues q ON q.id = j.queue_id
     WHERE q.project_id = ? AND je.status = 'completed'`,
    [projectId]
  );

  const failureRate = db.get(
    `SELECT
       SUM(CASE WHEN status IN ('completed') THEN 1 ELSE 0 END) as completed,
       SUM(CASE WHEN status IN ('dead_letter') THEN 1 ELSE 0 END) as dead_lettered
     FROM jobs j JOIN queues q ON q.id = j.queue_id WHERE q.project_id = ?`,
    [projectId]
  );

  return {
    jobCounts: Object.fromEntries(jobCounts.map((r) => [r.status, r.count])),
    workers: { online: workerCounts.online || 0, draining: workerCounts.draining || 0, offline: workerCounts.offline || 0 },
    throughputByHour,
    deadLetterCount: dlqCount.count,
    avgDurationMs: avgDuration.avg_ms,
    failureRate,
  };
}

module.exports = { overview };
