'use strict';

const db = require('../db');
const jobService = require('./jobService');
const ApiError = require('../utils/ApiError');

function register({ id, hostname, pid, concurrency }) {
  db.run(
    `INSERT INTO workers (id, hostname, pid, concurrency, status, last_heartbeat_at)
     VALUES (?, ?, ?, ?, 'online', datetime('now'))
     ON CONFLICT(id) DO UPDATE SET hostname=excluded.hostname, pid=excluded.pid,
       concurrency=excluded.concurrency, status='online', last_heartbeat_at=datetime('now')`,
    [id, hostname, pid, concurrency || 1]
  );
  return db.get('SELECT * FROM workers WHERE id = ?', [id]);
}

function heartbeat(id, { activeJobs } = {}) {
  const worker = db.get('SELECT * FROM workers WHERE id = ?', [id]);
  if (!worker) throw new ApiError(404, 'Worker not registered');

  db.run(
    `UPDATE workers SET last_heartbeat_at = datetime('now'), active_jobs = ? WHERE id = ?`,
    [activeJobs ?? worker.active_jobs, id]
  );
  db.run('INSERT INTO worker_heartbeats (worker_id, active_jobs) VALUES (?, ?)', [
    id, activeJobs ?? worker.active_jobs,
  ]);
  return db.get('SELECT * FROM workers WHERE id = ?', [id]);
}

function setStatus(id, status) {
  db.run('UPDATE workers SET status = ? WHERE id = ?', [status, id]);
  return db.get('SELECT * FROM workers WHERE id = ?', [id]);
}

function list() {
  // Consider a worker "stale/offline" if no heartbeat in the last 30s.
  return db.all(
    `SELECT *,
       CASE WHEN status != 'offline' AND last_heartbeat_at < datetime('now', '-30 seconds')
            THEN 1 ELSE 0 END as is_stale
     FROM workers ORDER BY started_at DESC`
  );
}

function claim({ workerId, maxJobs, queueIds }) {
  return jobService.claimJobs({ workerId, maxJobs, queueIds });
}

module.exports = { register, heartbeat, setStatus, list, claim };
