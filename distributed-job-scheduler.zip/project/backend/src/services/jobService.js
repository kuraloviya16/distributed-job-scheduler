'use strict';

const cronParser = require('cron-parser');
const db = require('../db');
const ApiError = require('../utils/ApiError');
const { computeBackoffMs } = require('../utils/retry');
const { toSqliteDateTime } = require('../utils/sqliteTime');
const logger = require('../utils/logger');

/**
 * Create a job. Supports all five submission modes via `mode`:
 *  - immediate: run_at = now
 *  - delayed:   run_at = now + delaySeconds
 *  - scheduled: run_at = explicit runAt timestamp
 *  - recurring: creates a `recurring_jobs` definition instead of a single job;
 *               the scheduler tick materializes concrete job rows from it.
 *  - batch:     creates a `batches` row + N job rows sharing batch_id.
 */
function createJob({ queueId, type, payload, mode, options = {} }) {
  const queue = db.get('SELECT * FROM queues WHERE id = ?', [queueId]);
  if (!queue) throw new ApiError(404, 'Queue not found');

  const retryPolicy = queue.retry_policy_id
    ? db.get('SELECT * FROM retry_policies WHERE id = ?', [queue.retry_policy_id])
    : null;

  const retryDefaults = {
    strategy: retryPolicy?.strategy || 'exponential',
    baseDelayMs: retryPolicy?.base_delay_ms ?? 1000,
    maxDelayMs: retryPolicy?.max_delay_ms ?? 300000,
    maxAttempts: retryPolicy?.max_attempts ?? 5,
  };

  if (mode === 'recurring') {
    return createRecurringDefinition({ queueId, type, payload, options });
  }

  if (mode === 'batch') {
    return createBatch({ queueId, type, items: options.items, retryDefaults, options });
  }

  let runAt = new Date();
  let status = 'queued';

  if (mode === 'delayed') {
    const delaySeconds = options.delaySeconds ?? 0;
    runAt = new Date(Date.now() + delaySeconds * 1000);
    status = 'scheduled';
  } else if (mode === 'scheduled') {
    if (!options.runAt) throw new ApiError(400, 'runAt is required for scheduled jobs');
    runAt = new Date(options.runAt);
    if (Number.isNaN(runAt.getTime())) throw new ApiError(400, 'runAt is not a valid date');
    status = 'scheduled';
  }

  return insertJob({
    queueId,
    type,
    payload,
    status,
    priority: options.priority ?? queue.priority,
    maxAttempts: options.maxAttempts ?? retryDefaults.maxAttempts,
    retryStrategy: options.retryStrategy ?? retryDefaults.strategy,
    baseDelayMs: options.baseDelayMs ?? retryDefaults.baseDelayMs,
    maxDelayMs: options.maxDelayMs ?? retryDefaults.maxDelayMs,
    runAt,
    idempotencyKey: options.idempotencyKey || null,
  });
}

function insertJob({
  queueId, type, payload, status, priority, maxAttempts, retryStrategy,
  baseDelayMs, maxDelayMs, runAt, idempotencyKey, batchId, recurringJobId,
}) {
  if (idempotencyKey) {
    const existing = db.get(
      'SELECT * FROM jobs WHERE queue_id = ? AND idempotency_key = ?',
      [queueId, idempotencyKey]
    );
    if (existing) return existing; // idempotent create: return the original
  }

  const info = db.run(
    `INSERT INTO jobs (
      queue_id, batch_id, recurring_job_id, type, payload, status, priority,
      max_attempts, retry_strategy, base_delay_ms, max_delay_ms, run_at, idempotency_key
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      queueId, batchId || null, recurringJobId || null, type, JSON.stringify(payload || {}),
      status, priority ?? 0, maxAttempts ?? 5, retryStrategy || 'exponential',
      baseDelayMs ?? 1000, maxDelayMs ?? 300000, toSqliteDateTime(runAt), idempotencyKey || null,
    ]
  );
  return getJob(Number(info.lastInsertRowid));
}

function createRecurringDefinition({ queueId, type, payload, options }) {
  if (!options.cronExpression) throw new ApiError(400, 'cronExpression is required for recurring jobs');
  if (!options.name) throw new ApiError(400, 'name is required for recurring jobs');

  let nextRun;
  try {
    const interval = cronParser.parseExpression(options.cronExpression, { tz: options.timezone || 'UTC' });
    nextRun = interval.next().toDate();
  } catch (err) {
    throw new ApiError(400, `Invalid cron expression: ${err.message}`);
  }

  const info = db.run(
    `INSERT INTO recurring_jobs (queue_id, name, cron_expression, timezone, job_type, payload, next_run_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      queueId, options.name, options.cronExpression, options.timezone || 'UTC',
      type, JSON.stringify(payload || {}), toSqliteDateTime(nextRun),
    ]
  );
  return db.get('SELECT * FROM recurring_jobs WHERE id = ?', [Number(info.lastInsertRowid)]);
}

function createBatch({ queueId, type, items, retryDefaults, options }) {
  if (!Array.isArray(items) || items.length === 0) {
    throw new ApiError(400, 'items (non-empty array) is required for batch jobs');
  }

  return db.transaction((conn) => {
    const batchInfo = conn
      .prepare('INSERT INTO batches (queue_id, name, total_jobs) VALUES (?, ?, ?)')
      .run(queueId, options.name || null, items.length);
    const batchId = Number(batchInfo.lastInsertRowid);

    const stmt = conn.prepare(
      `INSERT INTO jobs (queue_id, batch_id, type, payload, status, priority, max_attempts,
        retry_strategy, base_delay_ms, max_delay_ms, run_at)
       VALUES (?, ?, ?, ?, 'queued', ?, ?, ?, ?, ?, datetime('now'))`
    );
    for (const item of items) {
      stmt.run(
        queueId, batchId, type, JSON.stringify(item || {}),
        options.priority ?? 0, options.maxAttempts ?? retryDefaults.maxAttempts,
        options.retryStrategy ?? retryDefaults.strategy,
        options.baseDelayMs ?? retryDefaults.baseDelayMs,
        options.maxDelayMs ?? retryDefaults.maxDelayMs
      );
    }
    return conn.prepare('SELECT * FROM batches WHERE id = ?').get(batchId);
  });
}

function getJob(id) {
  const job = db.get('SELECT * FROM jobs WHERE id = ?', [id]);
  if (!job) throw new ApiError(404, 'Job not found');
  return job;
}

function listJobs({ queueId, status, type, limit, offset }) {
  const conditions = ['queue_id = ?'];
  const params = [queueId];
  if (status) { conditions.push('status = ?'); params.push(status); }
  if (type) { conditions.push('type = ?'); params.push(type); }

  const where = conditions.join(' AND ');
  const total = db.get(`SELECT COUNT(*) as count FROM jobs WHERE ${where}`, params).count;
  const rows = db.all(
    `SELECT * FROM jobs WHERE ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );
  return { rows, total };
}

/**
 * ATOMIC CLAIM — the core correctness guarantee of the whole system.
 *
 * A worker asks "give me up to N eligible jobs from queues I should serve,
 * and mark them as mine, in one indivisible step". We do this as:
 *   1. BEGIN IMMEDIATE (grabs the write lock — no other transaction can
 *      also be mid-write at the same time under SQLite's locking model)
 *   2. SELECT candidate ids ordered by priority/run_at
 *   3. UPDATE ... WHERE id IN (candidates) AND status='queued'  -- the
 *      WHERE re-check means even if something changed the row between
 *      steps 2 and 3 within this same transaction it's a no-op, and no
 *      other transaction could have run concurrently anyway.
 *   4. COMMIT
 *
 * In Postgres this same intent is expressed as:
 *   SELECT * FROM jobs WHERE status='queued' AND run_at <= now()
 *   ORDER BY priority DESC FOR UPDATE SKIP LOCKED LIMIT N;
 * which additionally allows multiple workers to claim from the same
 * queue truly concurrently (SKIP LOCKED lets each worker skip rows
 * already locked by another). That's the noted trade-off for this
 * SQLite-based reference implementation — see docs/DESIGN_DECISIONS.md.
 */
function claimJobs({ workerId, maxJobs = 1, queueIds = null }) {
  return db.transaction((conn) => {
    let sql = `
      SELECT j.id FROM jobs j
      JOIN queues q ON q.id = j.queue_id
      WHERE j.status IN ('queued','scheduled','retrying')
        AND j.run_at <= datetime('now')
        AND q.is_paused = 0
    `;
    const params = [];
    if (queueIds && queueIds.length > 0) {
      sql += ` AND j.queue_id IN (${queueIds.map(() => '?').join(',')})`;
      params.push(...queueIds);
    }
    sql += ' ORDER BY q.priority DESC, j.priority DESC, j.run_at ASC LIMIT ?';
    params.push(maxJobs);

    const candidates = conn.prepare(sql).all(...params);
    if (candidates.length === 0) return [];

    const claimed = [];
    const claimStmt = conn.prepare(
      `UPDATE jobs SET status = 'claimed', claimed_by = ?, claimed_at = datetime('now'), updated_at = datetime('now')
       WHERE id = ? AND status IN ('queued','scheduled','retrying')`
    );
    for (const c of candidates) {
      const info = claimStmt.run(workerId, c.id);
      if (info.changes === 1) {
        claimed.push(conn.prepare('SELECT * FROM jobs WHERE id = ?').get(c.id));
      }
    }
    return claimed;
  });
}

function markRunning(jobId, workerId) {
  db.run(
    `UPDATE jobs SET status = 'running', started_at = datetime('now'), attempt_count = attempt_count + 1,
     updated_at = datetime('now') WHERE id = ? AND claimed_by = ?`,
    [jobId, workerId]
  );
  const job = getJob(jobId);
  db.run(
    `INSERT INTO job_executions (job_id, attempt_number, worker_id, status)
     VALUES (?, ?, ?, 'running')`,
    [jobId, job.attempt_count, workerId]
  );
  return job;
}

function markCompleted(jobId, workerId, result) {
  return db.transaction((conn) => {
    conn.prepare(
      `UPDATE jobs SET status = 'completed', completed_at = datetime('now'), updated_at = datetime('now')
       WHERE id = ?`
    ).run(jobId);

    const execution = conn
      .prepare(`SELECT * FROM job_executions WHERE job_id = ? AND status = 'running' ORDER BY attempt_number DESC LIMIT 1`)
      .get(jobId);
    if (execution) {
      conn.prepare(
        `UPDATE job_executions SET status = 'completed', finished_at = datetime('now'),
         duration_ms = CAST((julianday('now') - julianday(started_at)) * 86400000 AS INTEGER),
         result = ? WHERE id = ?`
      ).run(JSON.stringify(result ?? null), execution.id);
    }

    bumpBatchCounters(conn, jobId, 'completed');
    return conn.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
  });
}

/**
 * Handle a failed attempt: either schedule a retry with backoff, or move
 * the job permanently to the Dead Letter Queue if attempts are exhausted.
 */
function markFailed(jobId, workerId, errorMessage) {
  return db.transaction((conn) => {
    const job = conn.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);

    const execution = conn
      .prepare(`SELECT * FROM job_executions WHERE job_id = ? AND status = 'running' ORDER BY attempt_number DESC LIMIT 1`)
      .get(jobId);
    if (execution) {
      conn.prepare(
        `UPDATE job_executions SET status = 'failed', finished_at = datetime('now'),
         duration_ms = CAST((julianday('now') - julianday(started_at)) * 86400000 AS INTEGER),
         error_message = ? WHERE id = ?`
      ).run(errorMessage, execution.id);
    }

    const exhausted = job.attempt_count >= job.max_attempts;

    if (exhausted) {
      conn.prepare(
        `UPDATE jobs SET status = 'dead_letter', last_error = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(errorMessage, jobId);

      conn.prepare(
        `INSERT INTO dead_letter_queue (job_id, queue_id, reason, payload_snapshot, attempt_count)
         VALUES (?, ?, ?, ?, ?)`
      ).run(jobId, job.queue_id, errorMessage, job.payload, job.attempt_count);

      bumpBatchCounters(conn, jobId, 'failed');
      logger.warn('Job moved to dead letter queue', { jobId, attempts: job.attempt_count });
    } else {
      const delayMs = computeBackoffMs({
        strategy: job.retry_strategy,
        baseDelayMs: job.base_delay_ms,
        maxDelayMs: job.max_delay_ms,
        attempt: job.attempt_count,
      });
      const nextRunAt = toSqliteDateTime(new Date(Date.now() + delayMs));

      conn.prepare(
        `UPDATE jobs SET status = 'retrying', last_error = ?, run_at = ?, claimed_by = NULL,
         claimed_at = NULL, updated_at = datetime('now') WHERE id = ?`
      ).run(errorMessage, nextRunAt, jobId);
    }

    return conn.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
  });
}

function bumpBatchCounters(conn, jobId, outcome) {
  const job = conn.prepare('SELECT batch_id FROM jobs WHERE id = ?').get(jobId);
  if (!job || !job.batch_id) return;

  const column = outcome === 'completed' ? 'completed_jobs' : 'failed_jobs';
  conn.prepare(`UPDATE batches SET ${column} = ${column} + 1 WHERE id = ?`).run(job.batch_id);

  const batch = conn.prepare('SELECT * FROM batches WHERE id = ?').get(job.batch_id);
  if (batch.completed_jobs + batch.failed_jobs >= batch.total_jobs) {
    const status = batch.failed_jobs > 0 ? 'completed_with_errors' : 'completed';
    conn.prepare('UPDATE batches SET status = ? WHERE id = ?').run(status, batch.id);
  } else if (batch.status === 'pending') {
    conn.prepare(`UPDATE batches SET status = 'in_progress' WHERE id = ?`).run(batch.id);
  }
}

/** Requeue transition happens automatically once run_at (set by markFailed) elapses; claimJobs picks it up. */

function retryDeadLetterJob(jobId) {
  return db.transaction((conn) => {
    const job = conn.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
    if (!job) throw new ApiError(404, 'Job not found');
    if (job.status !== 'dead_letter') throw new ApiError(400, 'Job is not in the dead letter queue');

    conn.prepare(
      `UPDATE jobs SET status = 'queued', attempt_count = 0, run_at = datetime('now'),
       last_error = NULL, claimed_by = NULL, claimed_at = NULL, updated_at = datetime('now')
       WHERE id = ?`
    ).run(jobId);

    return conn.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
  });
}

function cancelJob(jobId) {
  const job = getJob(jobId);
  if (['completed', 'dead_letter', 'cancelled'].includes(job.status)) {
    throw new ApiError(400, `Cannot cancel a job in status '${job.status}'`);
  }
  db.run(`UPDATE jobs SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?`, [jobId]);
  return getJob(jobId);
}

function jobLogs(jobId) {
  return db.all('SELECT * FROM job_logs WHERE job_id = ? ORDER BY created_at ASC', [jobId]);
}

function jobExecutions(jobId) {
  return db.all('SELECT * FROM job_executions WHERE job_id = ? ORDER BY attempt_number ASC', [jobId]);
}

module.exports = {
  createJob, getJob, listJobs, claimJobs, markRunning, markCompleted, markFailed,
  retryDeadLetterJob, cancelJob, jobLogs, jobExecutions,
};
