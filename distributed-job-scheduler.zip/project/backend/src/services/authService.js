'use strict';

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require('../db');
const ApiError = require('../utils/ApiError');
const { JWT_SECRET } = require('../middleware/auth');

async function register({ email, password, name, orgName }) {
  const existing = db.get('SELECT id FROM users WHERE email = ?', [email]);
  if (existing) throw new ApiError(409, 'Email already registered');

  const passwordHash = await bcrypt.hash(password, 10);

  const result = db.transaction((conn) => {
    const userStmt = conn.prepare(
      'INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)'
    );
    const userInfo = userStmt.run(email, passwordHash, name);
    const userId = Number(userInfo.lastInsertRowid);

    const orgStmt = conn.prepare('INSERT INTO organizations (name, owner_id) VALUES (?, ?)');
    const orgInfo = orgStmt.run(orgName || `${name}'s Organization`, userId);
    const orgId = Number(orgInfo.lastInsertRowid);

    conn.prepare(
      'INSERT INTO org_members (org_id, user_id, role) VALUES (?, ?, ?)'
    ).run(orgId, userId, 'owner');

    return { userId, orgId };
  });

  const token = signToken({ sub: result.userId, email });
  return { token, user: { id: result.userId, email, name }, organizationId: result.orgId };
}

async function login({ email, password }) {
  const user = db.get('SELECT * FROM users WHERE email = ?', [email]);
  if (!user) throw new ApiError(401, 'Invalid email or password');

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) throw new ApiError(401, 'Invalid email or password');

  const token = signToken({ sub: user.id, email: user.email });
  return { token, user: { id: user.id, email: user.email, name: user.name } };
}

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

function generateApiKey() {
  return 'sk_' + crypto.randomBytes(24).toString('hex');
}

module.exports = { register, login, generateApiKey };
