'use strict';

const cronParser = require('cron-parser');
const db = require('../db');
const { toSqliteDateTime } = require('../utils/sqliteTime');
const logger = require('../utils/logger');

/**
 * Materialize due recurring job definitions into concrete `jobs` rows.
 * Idempotent per tick: uses an idempotency key of `recurring:<id>:<next_run_at>`
 * so if the tick runs twice for the same slot (e.g. after a crash/restart)
 * we don't double-fire.
 */
function tick() {
  const due = db.all(
    `SELECT * FROM recurring_jobs WHERE is_active = 1 AND next_run_at <= datetime('now')`
  );

  for (const def of due) {
    db.transaction((conn) => {
      const idempotencyKey = `recurring:${def.id}:${def.next_run_at}`;
      const existing = conn
        .prepare('SELECT id FROM jobs WHERE queue_id = ? AND idempotency_key = ?')
        .get(def.queue_id, idempotencyKey);

      if (!existing) {
        conn.prepare(
          `INSERT INTO jobs (queue_id, recurring_job_id, type, payload, status, run_at, idempotency_key)
           VALUES (?, ?, ?, ?, 'queued', datetime('now'), ?)`
        ).run(def.queue_id, def.id, def.job_type, def.payload, idempotencyKey);
        logger.info('Materialized recurring job', { recurringJobId: def.id, name: def.name });
      }

      let nextRun;
      try {
        const interval = cronParser.parseExpression(def.cron_expression, { tz: def.timezone });
        nextRun = interval.next().toDate();
      } catch (err) {
        logger.error('Invalid cron expression, deactivating', { recurringJobId: def.id, error: err.message });
        conn.prepare('UPDATE recurring_jobs SET is_active = 0 WHERE id = ?').run(def.id);
        return;
      }

      conn.prepare(
        'UPDATE recurring_jobs SET last_run_at = datetime(\'now\'), next_run_at = ? WHERE id = ?'
      ).run(toSqliteDateTime(nextRun), def.id);
    });
  }

  return due.length;
}

let intervalHandle = null;

function start(intervalMs = 5000) {
  if (intervalHandle) return;
  intervalHandle = setInterval(() => {
    try {
      tick();
    } catch (err) {
      logger.error('Scheduler tick failed', { error: err.message });
    }
  }, intervalMs);
  logger.info('Scheduler started', { intervalMs });
}

function stop() {
  if (intervalHandle) clearInterval(intervalHandle);
  intervalHandle = null;
}

module.exports = { tick, start, stop };
