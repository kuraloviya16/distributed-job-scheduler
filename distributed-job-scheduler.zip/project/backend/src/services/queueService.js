'use strict';

const db = require('../db');
const ApiError = require('../utils/ApiError');

function create({ projectId, name, priority, concurrencyLimit, retryPolicy }) {
  let retryPolicyId = null;

  if (retryPolicy) {
    const info = db.run(
      `INSERT INTO retry_policies (project_id, name, strategy, base_delay_ms, max_delay_ms, max_attempts, jitter)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        projectId,
        `${name}-default-policy`,
        retryPolicy.strategy || 'exponential',
        retryPolicy.baseDelayMs ?? 1000,
        retryPolicy.maxDelayMs ?? 300000,
        retryPolicy.maxAttempts ?? 5,
        retryPolicy.jitter === false ? 0 : 1,
      ]
    );
    retryPolicyId = Number(info.lastInsertRowid);
  }

  const info = db.run(
    `INSERT INTO queues (project_id, name, priority, concurrency_limit, retry_policy_id)
     VALUES (?, ?, ?, ?, ?)`,
    [projectId, name, priority ?? 0, concurrencyLimit ?? 5, retryPolicyId]
  );
  return getById(Number(info.lastInsertRowid));
}

function getById(id) {
  const queue = db.get('SELECT * FROM queues WHERE id = ?', [id]);
  if (!queue) throw new ApiError(404, 'Queue not found');
  return queue;
}

function listForProject(projectId) {
  return db.all('SELECT * FROM queues WHERE project_id = ? ORDER BY priority DESC, name ASC', [
    projectId,
  ]);
}

function update(id, fields) {
  const queue = getById(id);
  const next = {
    priority: fields.priority ?? queue.priority,
    concurrency_limit: fields.concurrencyLimit ?? queue.concurrency_limit,
    is_paused: fields.isPaused === undefined ? queue.is_paused : fields.isPaused ? 1 : 0,
  };
  db.run(
    `UPDATE queues SET priority = ?, concurrency_limit = ?, is_paused = ?, updated_at = datetime('now')
     WHERE id = ?`,
    [next.priority, next.concurrency_limit, next.is_paused, id]
  );
  return getById(id);
}

function setPaused(id, paused) {
  return update(id, { isPaused: paused });
}

/** Aggregated stats: counts per status + running job count vs concurrency limit. */
function stats(id) {
  const queue = getById(id);
  const rows = db.all(
    'SELECT status, COUNT(*) as count FROM jobs WHERE queue_id = ? GROUP BY status',
    [id]
  );
  const counts = Object.fromEntries(rows.map((r) => [r.status, r.count]));

  const throughput = db.get(
    `SELECT COUNT(*) as completed_last_hour FROM jobs
     WHERE queue_id = ? AND status = 'completed' AND completed_at >= datetime('now', '-1 hour')`,
    [id]
  );

  const avgDuration = db.get(
    `SELECT AVG(duration_ms) as avg_duration_ms FROM job_executions je
     JOIN jobs j ON j.id = je.job_id
     WHERE j.queue_id = ? AND je.status = 'completed'`,
    [id]
  );

  return {
    queue,
    counts,
    running: counts.running || 0,
    concurrencyLimit: queue.concurrency_limit,
    completedLastHour: throughput.completed_last_hour,
    avgDurationMs: avgDuration.avg_duration_ms,
  };
}

module.exports = { create, getById, listForProject, update, setPaused, stats };
