'use strict';

const db = require('../db');
const ApiError = require('../utils/ApiError');
const { generateApiKey } = require('./authService');

function create({ orgId, name, description }) {
  const apiKey = generateApiKey();
  const info = db.run(
    'INSERT INTO projects (org_id, name, description, api_key) VALUES (?, ?, ?, ?)',
    [orgId, name, description || null, apiKey]
  );
  return get(Number(info.lastInsertRowid));
}

function get(id) {
  const project = db.get('SELECT * FROM projects WHERE id = ?', [id]);
  if (!project) throw new ApiError(404, 'Project not found');
  return project;
}

function listForUser(userId) {
  return db.all(
    `SELECT p.* FROM projects p
     JOIN org_members m ON m.org_id = p.org_id
     WHERE m.user_id = ?
     ORDER BY p.created_at DESC`,
    [userId]
  );
}

function rotateApiKey(id) {
  const apiKey = generateApiKey();
  db.run('UPDATE projects SET api_key = ? WHERE id = ?', [apiKey, id]);
  return get(id);
}

module.exports = { create, get, listForUser, rotateApiKey };
