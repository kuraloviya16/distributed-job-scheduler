'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth, loadProject } = require('../middleware/auth');
const metricsService = require('../services/metricsService');

const router = express.Router({ mergeParams: true });

router.use(requireAuth, loadProject);

router.get('/', asyncHandler((req, res) => {
  res.json({ data: metricsService.overview(req.project.id) });
}));

module.exports = router;
