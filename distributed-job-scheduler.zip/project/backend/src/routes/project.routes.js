'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth, loadProject, requireRole } = require('../middleware/auth');
const controller = require('../controllers/project.controller');

const router = express.Router();

router.use(requireAuth);

router.get('/', asyncHandler(controller.list));
router.post('/', asyncHandler(controller.create));
router.get('/:projectId', loadProject, asyncHandler(controller.getOne));
router.post(
  '/:projectId/rotate-key',
  loadProject,
  requireRole('owner', 'admin'),
  asyncHandler(controller.rotateKey)
);

module.exports = router;
