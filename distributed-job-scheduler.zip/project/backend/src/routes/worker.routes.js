'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth, requireApiKey } = require('../middleware/auth');
const db = require('../db');
const ApiError = require('../utils/ApiError');
const controller = require('../controllers/worker.controller');

const router = express.Router();

// Dashboard: list all workers (any authenticated user; in a stricter
// multi-tenant setup this would be scoped per-project/org).
router.get('/', requireAuth, asyncHandler(controller.list));

// Worker self-service endpoints, authenticated via project API key so a
// standalone worker process doesn't need a human user session.
router.use(requireApiKey);

router.post('/register', asyncHandler(controller.register));
router.post('/:workerId/heartbeat', asyncHandler(controller.heartbeat));
router.post('/:workerId/claim', asyncHandler(controller.claim));
router.post('/:workerId/drain', asyncHandler(controller.drain));
router.post('/:workerId/offline', asyncHandler(controller.offline));

// Job lifecycle transitions reported by the worker. Verify the job
// actually belongs to a queue under the authenticating project.
function verifyJobOwnership(req, res, next) {
  const job = db.get(
    `SELECT j.* FROM jobs j JOIN queues q ON q.id = j.queue_id WHERE j.id = ? AND q.project_id = ?`,
    [req.params.jobId, req.project.id]
  );
  if (!job) return next(new ApiError(404, 'Job not found for this project'));
  next();
}

router.post('/:workerId/jobs/:jobId/running', verifyJobOwnership, asyncHandler(controller.running));
router.post('/:workerId/jobs/:jobId/complete', verifyJobOwnership, asyncHandler(controller.complete));
router.post('/:workerId/jobs/:jobId/fail', verifyJobOwnership, asyncHandler(controller.fail));

module.exports = router;
