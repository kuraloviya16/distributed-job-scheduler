'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth } = require('../middleware/auth');
const db = require('../db');
const ApiError = require('../utils/ApiError');
const controller = require('../controllers/job.controller');

const router = express.Router();

router.use(requireAuth);

// Verify the requesting user's org owns the project this job belongs to.
function loadJobAuth(req, res, next) {
  const job = db.get('SELECT * FROM jobs WHERE id = ?', [req.params.jobId]);
  if (!job) return next(new ApiError(404, 'Job not found'));

  const owner = db.get(
    `SELECT p.org_id FROM queues q JOIN projects p ON p.id = q.project_id WHERE q.id = ?`,
    [job.queue_id]
  );
  const membership = db.get(
    'SELECT * FROM org_members WHERE org_id = ? AND user_id = ?',
    [owner.org_id, req.user.sub]
  );
  if (!membership) return next(new ApiError(403, 'Not authorized for this job'));
  next();
}

router.use('/:jobId', loadJobAuth);

router.get('/:jobId', asyncHandler(controller.getOne));
router.get('/:jobId/logs', asyncHandler(controller.logs));
router.get('/:jobId/executions', asyncHandler(controller.executions));
router.post('/:jobId/retry', asyncHandler(controller.retry));
router.post('/:jobId/cancel', asyncHandler(controller.cancel));

module.exports = router;
