'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth, loadProject } = require('../middleware/auth');
const db = require('../db');
const { parsePagination } = require('../utils/pagination');

const router = express.Router({ mergeParams: true });

router.use(requireAuth, loadProject);

router.get('/', asyncHandler((req, res) => {
  const { limit, offset } = parsePagination(req.query);
  const total = db.get(
    `SELECT COUNT(*) as count FROM dead_letter_queue d JOIN queues q ON q.id = d.queue_id WHERE q.project_id = ?`,
    [req.project.id]
  ).count;
  const rows = db.all(
    `SELECT d.*, q.name as queue_name FROM dead_letter_queue d
     JOIN queues q ON q.id = d.queue_id WHERE q.project_id = ?
     ORDER BY d.failed_at DESC LIMIT ? OFFSET ?`,
    [req.project.id, limit, offset]
  );
  res.json({ data: rows, pagination: { total, limit, offset } });
}));

module.exports = router;
