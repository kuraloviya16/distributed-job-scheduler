'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth, loadProject } = require('../middleware/auth');
const controller = require('../controllers/job.controller');

const router = express.Router({ mergeParams: true });

router.use(requireAuth, loadProject);

router.post('/', asyncHandler(controller.create));
router.get('/', asyncHandler(controller.list));

module.exports = router;
