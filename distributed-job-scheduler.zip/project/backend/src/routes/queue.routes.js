'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth, loadProject } = require('../middleware/auth');
const controller = require('../controllers/queue.controller');

// mergeParams so :projectId from the parent router is visible here
const router = express.Router({ mergeParams: true });

router.use(requireAuth, loadProject);

router.get('/', asyncHandler(controller.list));
router.post('/', asyncHandler(controller.create));
router.get('/:queueId', asyncHandler(controller.getOne));
router.patch('/:queueId', asyncHandler(controller.update));
router.post('/:queueId/pause', asyncHandler(controller.pause));
router.post('/:queueId/resume', asyncHandler(controller.resume));
router.get('/:queueId/stats', asyncHandler(controller.stats));

module.exports = router;
