'use strict';

require('dotenv').config();
const os = require('os');
const crypto = require('crypto');
const logger = require('../utils/logger');
const { getHandler } = require('./jobHandlers');

const API_BASE_URL = process.env.API_BASE_URL || 'http://localhost:4000';
const API_KEY = process.env.WORKER_API_KEY;
const CONCURRENCY = parseInt(process.env.WORKER_CONCURRENCY || '4', 10);
const POLL_INTERVAL_MS = parseInt(process.env.WORKER_POLL_INTERVAL_MS || '1000', 10);
const HEARTBEAT_INTERVAL_MS = parseInt(process.env.WORKER_HEARTBEAT_INTERVAL_MS || '10000', 10);

if (!API_KEY) {
  logger.error('WORKER_API_KEY is required (a project API key). See .env.example');
  process.exit(1);
}

const WORKER_ID = `${os.hostname()}:${process.pid}:${crypto.randomBytes(4).toString('hex')}`;

let activeCount = 0;
let draining = false;
let pollHandle = null;
let heartbeatHandle = null;

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-API-Key': API_KEY },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API ${method} ${path} -> ${res.status}: ${text}`);
  }
  return res.json();
}

async function register() {
  await api('/api/workers/register', {
    method: 'POST',
    body: { id: WORKER_ID, hostname: os.hostname(), pid: process.pid, concurrency: CONCURRENCY },
  });
  logger.info('Worker registered', { workerId: WORKER_ID, concurrency: CONCURRENCY });
}

async function sendHeartbeat() {
  try {
    await api(`/api/workers/${WORKER_ID}/heartbeat`, {
      method: 'POST',
      body: { activeJobs: activeCount },
    });
  } catch (err) {
    logger.warn('Heartbeat failed', { error: err.message });
  }
}

async function executeJob(job) {
  activeCount += 1;
  try {
    await api(`/api/workers/${WORKER_ID}/jobs/${job.id}/running`, { method: 'POST' });

    const handler = getHandler(job.type);
    if (!handler) throw new Error(`No handler registered for job type "${job.type}"`);

    const payload = JSON.parse(job.payload || '{}');
    logger.info('Executing job', { jobId: job.id, type: job.type, attempt: job.attempt_count + 1 });

    const result = await handler(payload);

    await api(`/api/workers/${WORKER_ID}/jobs/${job.id}/complete`, {
      method: 'POST',
      body: { result },
    });
    logger.info('Job completed', { jobId: job.id });
  } catch (err) {
    logger.warn('Job failed', { jobId: job.id, error: err.message });
    try {
      await api(`/api/workers/${WORKER_ID}/jobs/${job.id}/fail`, {
        method: 'POST',
        body: { error: err.message },
      });
    } catch (reportErr) {
      logger.error('Failed to report job failure to API', { jobId: job.id, error: reportErr.message });
    }
  } finally {
    activeCount -= 1;
  }
}

async function pollAndClaim() {
  if (draining) return;
  const capacity = CONCURRENCY - activeCount;
  if (capacity <= 0) return;

  try {
    const { data: jobs } = await api(`/api/workers/${WORKER_ID}/claim`, {
      method: 'POST',
      body: { maxJobs: capacity },
    });
    for (const job of jobs) {
      // Fire-and-forget: each job runs concurrently, bounded by CONCURRENCY
      // via the activeCount/capacity check above.
      executeJob(job);
    }
  } catch (err) {
    logger.warn('Poll/claim failed', { error: err.message });
  }
}

async function gracefulShutdown(signal) {
  if (draining) return;
  draining = true;
  logger.info(`Received ${signal}, draining worker (no new jobs, waiting on in-flight jobs)`, {
    workerId: WORKER_ID,
    activeJobs: activeCount,
  });

  clearInterval(pollHandle);
  clearInterval(heartbeatHandle);

  try {
    await api(`/api/workers/${WORKER_ID}/drain`, { method: 'POST' });
  } catch (_) { /* best-effort */ }

  const start = Date.now();
  const maxWaitMs = 30000;
  while (activeCount > 0 && Date.now() - start < maxWaitMs) {
    await new Promise((r) => setTimeout(r, 250));
  }

  try {
    await api(`/api/workers/${WORKER_ID}/offline`, { method: 'POST' });
  } catch (_) { /* best-effort */ }

  logger.info('Worker shut down cleanly', { workerId: WORKER_ID });
  process.exit(0);
}

async function main() {
  await register();
  await sendHeartbeat();

  pollHandle = setInterval(pollAndClaim, POLL_INTERVAL_MS);
  heartbeatHandle = setInterval(sendHeartbeat, HEARTBEAT_INTERVAL_MS);

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

main().catch((err) => {
  logger.error('Worker failed to start', { error: err.message });
  process.exit(1);
});
