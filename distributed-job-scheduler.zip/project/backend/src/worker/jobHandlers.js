'use strict';

/**
 * Job handlers are pure async functions: (payload) => result.
 * Throw to signal failure (the worker catches it and reports it, which
 * triggers the retry/backoff/DLQ logic on the server).
 */
const handlers = {
  echo: async (payload) => {
    return { echoed: payload };
  },

  sleep: async (payload) => {
    const ms = payload?.ms ?? 1000;
    await new Promise((resolve) => setTimeout(resolve, ms));
    return { sleptMs: ms };
  },

  http_request: async (payload) => {
    const { url, method = 'GET' } = payload || {};
    if (!url) throw new Error('http_request job requires a "url" in payload');
    const res = await fetch(url, { method });
    if (!res.ok) throw new Error(`HTTP ${res.status} from ${url}`);
    return { status: res.status };
  },

  // Deliberately-failing handler, useful for demoing retry/backoff/DLQ.
  fail_test: async (payload) => {
    throw new Error(payload?.message || 'Simulated failure for testing');
  },

  send_email: async (payload) => {
    // Placeholder: in a real system this would call an email provider.
    if (!payload?.to) throw new Error('send_email job requires "to" in payload');
    return { sentTo: payload.to, subject: payload.subject || '(no subject)' };
  },
};

function getHandler(type) {
  return handlers[type];
}

function registerHandler(type, fn) {
  handlers[type] = fn;
}

module.exports = { getHandler, registerHandler, handlers };
