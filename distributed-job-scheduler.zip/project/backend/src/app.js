'use strict';

const express = require('express');
const cors = require('cors');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const authRoutes = require('./routes/auth.routes');
const projectRoutes = require('./routes/project.routes');
const queueRoutes = require('./routes/queue.routes');
const jobRoutes = require('./routes/job.routes');
const jobDetailRoutes = require('./routes/jobDetail.routes');
const workerRoutes = require('./routes/worker.routes');
const metricsRoutes = require('./routes/metrics.routes');
const dlqRoutes = require('./routes/dlq.routes');

function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '2mb' }));

  app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

  app.use('/api/auth', authRoutes);
  app.use('/api/projects', projectRoutes);
  app.use('/api/projects/:projectId/queues', queueRoutes);
  app.use('/api/projects/:projectId/queues/:queueId/jobs', jobRoutes);
  app.use('/api/jobs', jobDetailRoutes);
  app.use('/api/workers', workerRoutes);
  app.use('/api/projects/:projectId/metrics', metricsRoutes);
  app.use('/api/projects/:projectId/dead-letter-queue', dlqRoutes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

module.exports = createApp;
