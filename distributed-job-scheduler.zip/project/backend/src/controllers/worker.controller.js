'use strict';

const workerService = require('../services/workerService');
const jobService = require('../services/jobService');
const ApiError = require('../utils/ApiError');

function register(req, res) {
  const { id, hostname, pid, concurrency } = req.body;
  if (!id || !hostname || !pid) throw new ApiError(400, 'id, hostname, and pid are required');
  res.status(201).json({ data: workerService.register({ id, hostname, pid, concurrency }) });
}

function heartbeat(req, res) {
  res.json({ data: workerService.heartbeat(req.params.workerId, req.body) });
}

function claim(req, res) {
  const { maxJobs, queueIds } = req.body;
  res.json({ data: workerService.claim({ workerId: req.params.workerId, maxJobs, queueIds }) });
}

function running(req, res) {
  res.json({ data: jobService.markRunning(req.params.jobId, req.params.workerId) });
}

function complete(req, res) {
  res.json({ data: jobService.markCompleted(req.params.jobId, req.params.workerId, req.body.result) });
}

function fail(req, res) {
  const { error } = req.body;
  if (!error) throw new ApiError(400, 'error message is required');
  res.json({ data: jobService.markFailed(req.params.jobId, req.params.workerId, error) });
}

function drain(req, res) {
  res.json({ data: workerService.setStatus(req.params.workerId, 'draining') });
}

function offline(req, res) {
  res.json({ data: workerService.setStatus(req.params.workerId, 'offline') });
}

function list(req, res) {
  res.json({ data: workerService.list() });
}

module.exports = { register, heartbeat, claim, running, complete, fail, drain, offline, list };
