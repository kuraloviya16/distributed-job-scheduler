'use strict';

const authService = require('../services/authService');
const ApiError = require('../utils/ApiError');

async function register(req, res) {
  const { email, password, name, orgName } = req.body;
  if (!email || !password || !name) {
    throw new ApiError(400, 'email, password, and name are required');
  }
  if (password.length < 8) {
    throw new ApiError(400, 'password must be at least 8 characters');
  }
  const result = await authService.register({ email, password, name, orgName });
  res.status(201).json(result);
}

async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) throw new ApiError(400, 'email and password are required');
  const result = await authService.login({ email, password });
  res.json(result);
}

module.exports = { register, login };
