'use strict';

const queueService = require('../services/queueService');
const ApiError = require('../utils/ApiError');

function list(req, res) {
  res.json({ data: queueService.listForProject(req.project.id) });
}

function create(req, res) {
  const { name, priority, concurrencyLimit, retryPolicy } = req.body;
  if (!name) throw new ApiError(400, 'name is required');
  const queue = queueService.create({
    projectId: req.project.id,
    name,
    priority,
    concurrencyLimit,
    retryPolicy,
  });
  res.status(201).json({ data: queue });
}

function getOne(req, res) {
  res.json({ data: queueService.getById(req.params.queueId) });
}

function update(req, res) {
  const queue = queueService.update(req.params.queueId, req.body);
  res.json({ data: queue });
}

function pause(req, res) {
  res.json({ data: queueService.setPaused(req.params.queueId, true) });
}

function resume(req, res) {
  res.json({ data: queueService.setPaused(req.params.queueId, false) });
}

function stats(req, res) {
  res.json({ data: queueService.stats(req.params.queueId) });
}

module.exports = { list, create, getOne, update, pause, resume, stats };
