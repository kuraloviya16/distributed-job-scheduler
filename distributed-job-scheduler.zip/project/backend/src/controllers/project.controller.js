'use strict';

const db = require('../db');
const projectService = require('../services/projectService');
const ApiError = require('../utils/ApiError');

function list(req, res) {
  res.json({ data: projectService.listForUser(req.user.sub) });
}

function create(req, res) {
  const { name, description, orgId } = req.body;
  if (!name) throw new ApiError(400, 'name is required');

  // Default to the user's first org (created at registration) if not specified.
  const org = orgId
    ? db.get('SELECT * FROM organizations WHERE id = ?', [orgId])
    : db.get(
        `SELECT o.* FROM organizations o
         JOIN org_members m ON m.org_id = o.id
         WHERE m.user_id = ? ORDER BY o.created_at ASC LIMIT 1`,
        [req.user.sub]
      );
  if (!org) throw new ApiError(400, 'No organization found; provide orgId');

  const membership = db.get(
    'SELECT * FROM org_members WHERE org_id = ? AND user_id = ?',
    [org.id, req.user.sub]
  );
  if (!membership) throw new ApiError(403, 'Not a member of this organization');

  const project = projectService.create({ orgId: org.id, name, description });
  res.status(201).json({ data: project });
}

function getOne(req, res) {
  res.json({ data: req.project });
}

function rotateKey(req, res) {
  res.json({ data: projectService.rotateApiKey(req.project.id) });
}

module.exports = { list, create, getOne, rotateKey };
