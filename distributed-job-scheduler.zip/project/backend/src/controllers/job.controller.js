'use strict';

const jobService = require('../services/jobService');
const ApiError = require('../utils/ApiError');
const { parsePagination } = require('../utils/pagination');

function create(req, res) {
  const { type, payload, mode = 'immediate', options } = req.body;
  if (!type) throw new ApiError(400, 'type is required');
  const validModes = ['immediate', 'delayed', 'scheduled', 'recurring', 'batch'];
  if (!validModes.includes(mode)) throw new ApiError(400, `mode must be one of ${validModes.join(', ')}`);

  const result = jobService.createJob({
    queueId: req.params.queueId,
    type,
    payload,
    mode,
    options: options || {},
  });
  res.status(201).json({ data: result });
}

function list(req, res) {
  const { limit, offset } = parsePagination(req.query);
  const { rows, total } = jobService.listJobs({
    queueId: req.params.queueId,
    status: req.query.status,
    type: req.query.type,
    limit,
    offset,
  });
  res.json({ data: rows, pagination: { total, limit, offset } });
}

function getOne(req, res) {
  res.json({ data: jobService.getJob(req.params.jobId) });
}

function logs(req, res) {
  res.json({ data: jobService.jobLogs(req.params.jobId) });
}

function executions(req, res) {
  res.json({ data: jobService.jobExecutions(req.params.jobId) });
}

function retry(req, res) {
  res.json({ data: jobService.retryDeadLetterJob(req.params.jobId) });
}

function cancel(req, res) {
  res.json({ data: jobService.cancelJob(req.params.jobId) });
}

module.exports = { create, list, getOne, logs, executions, retry, cancel };
