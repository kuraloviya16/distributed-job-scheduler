-- =====================================================================
-- Distributed Job Scheduler - Relational Schema
-- Engine: SQLite (via Node.js built-in `node:sqlite`)
-- Notes on portability: written in standard SQL; the only SQLite-specific
-- pieces are AUTOINCREMENT and STRICT tables. Porting to Postgres means:
--   INTEGER PRIMARY KEY AUTOINCREMENT -> BIGSERIAL / IDENTITY
--   TEXT (json)                       -> JSONB
--   DATETIME                          -> TIMESTAMPTZ
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- Users & Organizations (Auth + multi-tenancy)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  name          TEXT NOT NULL,
  created_at    DATETIME NOT NULL DEFAULT (datetime('now')),
  updated_at    DATETIME NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS organizations (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  owner_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at DATETIME NOT NULL DEFAULT (datetime('now'))
);

-- Bonus: role-based access control. A user can belong to multiple orgs.
CREATE TABLE IF NOT EXISTS org_members (
  org_id     INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role       TEXT NOT NULL CHECK (role IN ('owner','admin','member','viewer')) DEFAULT 'member',
  created_at DATETIME NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (org_id, user_id)
);

CREATE TABLE IF NOT EXISTS projects (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id      INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  description TEXT,
  api_key     TEXT NOT NULL UNIQUE,
  created_at  DATETIME NOT NULL DEFAULT (datetime('now')),
  UNIQUE (org_id, name)
);

-- ---------------------------------------------------------------------
-- Retry Policies (reusable, attached to a queue; a job snapshots the
-- effective values at creation time so later edits don't retroactively
-- change in-flight jobs)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS retry_policies (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id    INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  strategy      TEXT NOT NULL CHECK (strategy IN ('fixed','linear','exponential')) DEFAULT 'exponential',
  base_delay_ms INTEGER NOT NULL DEFAULT 1000,
  max_delay_ms  INTEGER NOT NULL DEFAULT 300000,
  max_attempts  INTEGER NOT NULL DEFAULT 5,
  jitter        INTEGER NOT NULL DEFAULT 1, -- boolean 0/1
  created_at    DATETIME NOT NULL DEFAULT (datetime('now')),
  UNIQUE (project_id, name)
);

-- ---------------------------------------------------------------------
-- Queues
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS queues (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id         INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,
  priority           INTEGER NOT NULL DEFAULT 0,        -- higher = served first
  concurrency_limit  INTEGER NOT NULL DEFAULT 5,         -- max jobs running at once for this queue
  retry_policy_id    INTEGER REFERENCES retry_policies(id) ON DELETE SET NULL,
  is_paused          INTEGER NOT NULL DEFAULT 0,
  created_at         DATETIME NOT NULL DEFAULT (datetime('now')),
  updated_at         DATETIME NOT NULL DEFAULT (datetime('now')),
  UNIQUE (project_id, name)
);

-- ---------------------------------------------------------------------
-- Batches (group of jobs submitted together, e.g. "batch job" type)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS batches (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  queue_id       INTEGER NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
  name           TEXT,
  total_jobs     INTEGER NOT NULL DEFAULT 0,
  completed_jobs INTEGER NOT NULL DEFAULT 0,
  failed_jobs    INTEGER NOT NULL DEFAULT 0,
  status         TEXT NOT NULL CHECK (status IN ('pending','in_progress','completed','completed_with_errors')) DEFAULT 'pending',
  created_at     DATETIME NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------
-- Recurring job definitions (cron). The scheduler tick materializes
-- concrete rows in `jobs` from these definitions.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS recurring_jobs (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  queue_id         INTEGER NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
  name             TEXT NOT NULL,
  cron_expression  TEXT NOT NULL,
  timezone         TEXT NOT NULL DEFAULT 'UTC',
  job_type         TEXT NOT NULL,
  payload          TEXT NOT NULL DEFAULT '{}', -- JSON
  is_active        INTEGER NOT NULL DEFAULT 1,
  next_run_at      DATETIME,
  last_run_at      DATETIME,
  created_at       DATETIME NOT NULL DEFAULT (datetime('now')),
  UNIQUE (queue_id, name)
);

-- ---------------------------------------------------------------------
-- Jobs (the central table). Polling index is the critical performance
-- path: workers scan for (status='queued' AND run_at <= now) ordered by
-- priority. See idx_jobs_poll below.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS jobs (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  queue_id         INTEGER NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
  batch_id         INTEGER REFERENCES batches(id) ON DELETE SET NULL,
  recurring_job_id INTEGER REFERENCES recurring_jobs(id) ON DELETE SET NULL,
  type             TEXT NOT NULL,
  payload          TEXT NOT NULL DEFAULT '{}',      -- JSON
  status           TEXT NOT NULL CHECK (status IN
                     ('queued','scheduled','claimed','running','completed','failed','retrying','dead_letter','cancelled')
                    ) DEFAULT 'queued',
  priority         INTEGER NOT NULL DEFAULT 0,
  max_attempts     INTEGER NOT NULL DEFAULT 5,
  attempt_count    INTEGER NOT NULL DEFAULT 0,
  retry_strategy   TEXT NOT NULL DEFAULT 'exponential',
  base_delay_ms    INTEGER NOT NULL DEFAULT 1000,
  max_delay_ms     INTEGER NOT NULL DEFAULT 300000,
  run_at           DATETIME NOT NULL DEFAULT (datetime('now')), -- when it becomes eligible to run
  idempotency_key  TEXT,
  claimed_by       TEXT,                              -- worker_id
  claimed_at       DATETIME,
  started_at       DATETIME,
  completed_at     DATETIME,
  last_error       TEXT,
  created_at       DATETIME NOT NULL DEFAULT (datetime('now')),
  updated_at       DATETIME NOT NULL DEFAULT (datetime('now')),
  UNIQUE (queue_id, idempotency_key)
);

-- Critical polling index: partial-index-like ordering for the worker's
-- "find next job" query. SQLite doesn't support partial indexes with
-- dynamic `now()`, so we index the full tuple and filter in the query.
CREATE INDEX IF NOT EXISTS idx_jobs_poll ON jobs (queue_id, status, run_at, priority DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs (status);
CREATE INDEX IF NOT EXISTS idx_jobs_claimed_by ON jobs (claimed_by);
CREATE INDEX IF NOT EXISTS idx_jobs_batch ON jobs (batch_id);

-- ---------------------------------------------------------------------
-- Job Executions (one row per attempt -> full retry history)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS job_executions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id          INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  attempt_number  INTEGER NOT NULL,
  worker_id       TEXT NOT NULL,
  status          TEXT NOT NULL CHECK (status IN ('running','completed','failed')),
  started_at      DATETIME NOT NULL DEFAULT (datetime('now')),
  finished_at     DATETIME,
  duration_ms     INTEGER,
  error_message   TEXT,
  result          TEXT, -- JSON
  UNIQUE (job_id, attempt_number)
);

CREATE INDEX IF NOT EXISTS idx_executions_job ON job_executions (job_id);

-- ---------------------------------------------------------------------
-- Workers & Heartbeats
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS workers (
  id                TEXT PRIMARY KEY,     -- e.g. hostname:pid:uuid, generated by worker on boot
  hostname          TEXT NOT NULL,
  pid               INTEGER NOT NULL,
  status            TEXT NOT NULL CHECK (status IN ('online','draining','offline')) DEFAULT 'online',
  concurrency       INTEGER NOT NULL DEFAULT 1,
  active_jobs       INTEGER NOT NULL DEFAULT 0,
  started_at        DATETIME NOT NULL DEFAULT (datetime('now')),
  last_heartbeat_at DATETIME NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS worker_heartbeats (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  worker_id   TEXT NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  active_jobs INTEGER NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_heartbeats_worker ON worker_heartbeats (worker_id, created_at);

-- ---------------------------------------------------------------------
-- Job Logs (structured, per execution)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS job_logs (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id       INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  execution_id INTEGER REFERENCES job_executions(id) ON DELETE CASCADE,
  level        TEXT NOT NULL CHECK (level IN ('debug','info','warn','error')) DEFAULT 'info',
  message      TEXT NOT NULL,
  created_at   DATETIME NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_logs_job ON job_logs (job_id);

-- ---------------------------------------------------------------------
-- Dead Letter Queue (permanent failures, kept separately from jobs so
-- the hot `jobs` table stays small and the poll index stays cheap)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dead_letter_queue (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id          INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  queue_id        INTEGER NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
  reason          TEXT NOT NULL,
  payload_snapshot TEXT NOT NULL,
  attempt_count   INTEGER NOT NULL,
  failed_at       DATETIME NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_dlq_queue ON dead_letter_queue (queue_id);
