'use strict';

require('dotenv').config();
const createApp = require('./app');
const db = require('./db');
const scheduler = require('./services/schedulerService');
const logger = require('./utils/logger');

db.init();

const app = createApp();
const PORT = process.env.PORT || 4000;

const server = app.listen(PORT, () => {
  logger.info(`API server listening on port ${PORT}`);
  scheduler.start(5000);
});

function shutdown(signal) {
  logger.info(`Received ${signal}, shutting down gracefully`);
  scheduler.stop();
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

module.exports = server;
