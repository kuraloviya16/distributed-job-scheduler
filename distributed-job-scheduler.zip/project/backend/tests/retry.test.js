'use strict';

const test = require('node:test');
const assert = require('node:assert');
const { computeBackoffMs } = require('../src/utils/retry');

test('fixed strategy always returns the base delay (jitter off)', () => {
  const d1 = computeBackoffMs({ strategy: 'fixed', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 1, jitter: false });
  const d2 = computeBackoffMs({ strategy: 'fixed', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 5, jitter: false });
  assert.strictEqual(d1, 1000);
  assert.strictEqual(d2, 1000);
});

test('linear strategy grows proportionally to attempt number', () => {
  const d1 = computeBackoffMs({ strategy: 'linear', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 1, jitter: false });
  const d3 = computeBackoffMs({ strategy: 'linear', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 3, jitter: false });
  assert.strictEqual(d1, 1000);
  assert.strictEqual(d3, 3000);
});

test('exponential strategy doubles each attempt', () => {
  const d1 = computeBackoffMs({ strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 1, jitter: false });
  const d2 = computeBackoffMs({ strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 2, jitter: false });
  const d4 = computeBackoffMs({ strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 4, jitter: false });
  assert.strictEqual(d1, 1000);
  assert.strictEqual(d2, 2000);
  assert.strictEqual(d4, 8000);
});

test('delay is capped at maxDelayMs', () => {
  const d = computeBackoffMs({ strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 5000, attempt: 10, jitter: false });
  assert.strictEqual(d, 5000);
});

test('jitter keeps the delay within [0, computed delay]', () => {
  for (let i = 0; i < 50; i++) {
    const raw = computeBackoffMs({ strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 3, jitter: false });
    const jittered = computeBackoffMs({ strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 60000, attempt: 3, jitter: true });
    assert.ok(jittered >= 0 && jittered <= raw, `jittered=${jittered} should be within [0, ${raw}]`);
  }
});
