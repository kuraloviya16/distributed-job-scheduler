'use strict';

const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');

const TEST_DB = path.join(__dirname, 'tmp-lifecycle.db');
fs.rmSync(TEST_DB, { force: true });
fs.rmSync(TEST_DB + '-wal', { force: true });
fs.rmSync(TEST_DB + '-shm', { force: true });
process.env.DB_PATH = TEST_DB;

const db = require('../src/db');
const jobService = require('../src/services/jobService');

db.init();
db.run(`INSERT INTO users (id, email, password_hash, name) VALUES (1, 'a@a.com', 'x', 'A')`);
db.run(`INSERT INTO organizations (id, name, owner_id) VALUES (1, 't', 1)`);
const project = db.run(`INSERT INTO projects (org_id, name, api_key) VALUES (1, 'p', 'key1')`);
const projectId = Number(project.lastInsertRowid);
const queueInfo = db.run(
  `INSERT INTO queues (project_id, name, priority, concurrency_limit) VALUES (?, 'q', 0, 10)`,
  [projectId]
);
const queueId = Number(queueInfo.lastInsertRowid);

test('a job that keeps failing moves through retrying and lands in dead_letter after max_attempts', () => {
  const job = jobService.createJob({
    queueId,
    type: 'fail_test',
    payload: {},
    mode: 'immediate',
    options: { maxAttempts: 2, baseDelayMs: 10 },
  });

  // Attempt 1: claim -> running -> fail -> should go to "retrying"
  let [claimed] = jobService.claimJobs({ workerId: 'w1', maxJobs: 1, queueIds: [queueId] });
  assert.strictEqual(claimed.id, job.id);
  jobService.markRunning(claimed.id, 'w1');
  let afterFail = jobService.markFailed(claimed.id, 'w1', 'boom 1');
  assert.strictEqual(afterFail.status, 'retrying');
  assert.strictEqual(afterFail.attempt_count, 1);

  // Force run_at into the past so the retry is immediately eligible
  // (in production this happens naturally once the backoff elapses).
  db.run(`UPDATE jobs SET run_at = datetime('now', '-1 second') WHERE id = ?`, [claimed.id]);

  // Attempt 2 (final, max_attempts=2): claim -> running -> fail -> dead_letter
  [claimed] = jobService.claimJobs({ workerId: 'w1', maxJobs: 1, queueIds: [queueId] });
  assert.strictEqual(claimed.id, job.id);
  jobService.markRunning(claimed.id, 'w1');
  afterFail = jobService.markFailed(claimed.id, 'w1', 'boom 2');
  assert.strictEqual(afterFail.status, 'dead_letter');
  assert.strictEqual(afterFail.attempt_count, 2);

  const dlqRow = db.get('SELECT * FROM dead_letter_queue WHERE job_id = ?', [claimed.id]);
  assert.ok(dlqRow, 'a dead_letter_queue row should exist for the exhausted job');
  assert.strictEqual(dlqRow.attempt_count, 2);

  // A dead-lettered job must not be claimable again.
  const claimedAgain = jobService.claimJobs({ workerId: 'w2', maxJobs: 5, queueIds: [queueId] });
  assert.strictEqual(claimedAgain.length, 0);
});

test('a completed job records execution history with duration', () => {
  const job = jobService.createJob({ queueId, type: 'echo', payload: {}, mode: 'immediate' });
  const [claimed] = jobService.claimJobs({ workerId: 'w1', maxJobs: 1, queueIds: [queueId] });
  jobService.markRunning(claimed.id, 'w1');
  jobService.markCompleted(claimed.id, 'w1', { ok: true });

  const finalJob = jobService.getJob(job.id);
  assert.strictEqual(finalJob.status, 'completed');

  const executions = jobService.jobExecutions(job.id);
  assert.strictEqual(executions.length, 1);
  assert.strictEqual(executions[0].status, 'completed');
  assert.strictEqual(JSON.parse(executions[0].result).ok, true);
});

test('retrying a dead-lettered job resets it to queued', () => {
  const job = jobService.createJob({
    queueId, type: 'fail_test', payload: {}, mode: 'immediate',
    options: { maxAttempts: 1 },
  });
  const [claimed] = jobService.claimJobs({ workerId: 'w1', maxJobs: 1, queueIds: [queueId] });
  jobService.markRunning(claimed.id, 'w1');
  const dead = jobService.markFailed(claimed.id, 'w1', 'fail');
  assert.strictEqual(dead.status, 'dead_letter');

  const revived = jobService.retryDeadLetterJob(job.id);
  assert.strictEqual(revived.status, 'queued');
  assert.strictEqual(revived.attempt_count, 0);
});

test('idempotency key prevents duplicate job creation', () => {
  const a = jobService.createJob({
    queueId, type: 'echo', payload: { n: 1 }, mode: 'immediate',
    options: { idempotencyKey: 'unique-key-1' },
  });
  const b = jobService.createJob({
    queueId, type: 'echo', payload: { n: 2 }, mode: 'immediate',
    options: { idempotencyKey: 'unique-key-1' },
  });
  assert.strictEqual(a.id, b.id, 'second create with the same idempotency key should return the original job');
});
