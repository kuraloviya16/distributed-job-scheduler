'use strict';

const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');

const TEST_DB = path.join(__dirname, 'tmp-claim.db');
fs.rmSync(TEST_DB, { force: true });
fs.rmSync(TEST_DB + '-wal', { force: true });
fs.rmSync(TEST_DB + '-shm', { force: true });
process.env.DB_PATH = TEST_DB;

const db = require('../src/db');
const jobService = require('../src/services/jobService');

db.init();
db.run(`INSERT INTO users (id, email, password_hash, name) VALUES (1, 'a@a.com', 'x', 'A')`);
db.run(`INSERT INTO organizations (id, name, owner_id) VALUES (1, 't', 1)`);

let projectCounter = 0;

function makeQueue() {
  projectCounter += 1;
  const project = db.run(
    `INSERT INTO projects (org_id, name, api_key) VALUES (1, ?, ?)`,
    [`p${projectCounter}`, `key${projectCounter}`]
  );
  const queueInfo = db.run(
    `INSERT INTO queues (project_id, name, priority, concurrency_limit) VALUES (?, 'q', 0, 10)`,
    [Number(project.lastInsertRowid)]
  );
  return Number(queueInfo.lastInsertRowid);
}

test('claiming the same job from two concurrent "workers" only succeeds once', () => {
  const queueId = makeQueue();
  const job = jobService.createJob({
    queueId,
    type: 'echo',
    payload: {},
    mode: 'immediate',
  });

  // Simulate two workers racing to claim from the same queue. Because
  // claimJobs() runs inside BEGIN IMMEDIATE, these calls are serialized
  // at the SQLite level even though we invoke them "concurrently" here.
  const resultA = jobService.claimJobs({ workerId: 'worker-A', maxJobs: 5, queueIds: [queueId] });
  const resultB = jobService.claimJobs({ workerId: 'worker-B', maxJobs: 5, queueIds: [queueId] });

  const claimedByA = resultA.some((j) => j.id === job.id);
  const claimedByB = resultB.some((j) => j.id === job.id);

  assert.notStrictEqual(claimedByA, claimedByB, 'exactly one worker should have claimed the job');
  assert.strictEqual(claimedByA && claimedByB, false, 'both workers must not claim the same job');

  const finalJob = jobService.getJob(job.id);
  assert.strictEqual(finalJob.status, 'claimed');
  assert.ok(['worker-A', 'worker-B'].includes(finalJob.claimed_by));
});

test('claimJobs does not return jobs from paused queues', () => {
  const queueId = makeQueue();
  db.run(`UPDATE queues SET is_paused = 1 WHERE id = ?`, [queueId]);
  jobService.createJob({ queueId, type: 'echo', payload: {}, mode: 'immediate' });

  const claimed = jobService.claimJobs({ workerId: 'worker-X', maxJobs: 5, queueIds: [queueId] });
  assert.strictEqual(claimed.length, 0);
});

test('claimJobs respects run_at for delayed/scheduled jobs (not yet eligible)', () => {
  const queueId = makeQueue();
  jobService.createJob({
    queueId,
    type: 'echo',
    payload: {},
    mode: 'delayed',
    options: { delaySeconds: 3600 },
  });

  const claimed = jobService.claimJobs({ workerId: 'worker-Y', maxJobs: 5, queueIds: [queueId] });
  assert.strictEqual(claimed.length, 0, 'a job scheduled an hour from now should not be claimable yet');
});
