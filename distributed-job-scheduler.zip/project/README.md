# Distributed Job Scheduler

A production-inspired distributed job scheduling platform: REST API +
worker service + React dashboard, supporting immediate, delayed,
scheduled (cron), recurring, and batch jobs with atomic claiming,
configurable retry strategies, and a dead letter queue.

📄 **Docs:** [Architecture](docs/ARCHITECTURE.md) · [ER Diagram](docs/ER_DIAGRAM.md) ·
[API Reference](docs/API_DOCUMENTATION.md) · [Design Decisions](docs/DESIGN_DECISIONS.md)

## Project structure

```
backend/
  src/
    db/               schema.sql + connection helper (node:sqlite)
    services/         business logic (job lifecycle, retries, scheduler, metrics)
    controllers/       thin request handlers
    routes/           Express routers
    middleware/       auth (JWT + API key), error handling
    worker/           standalone worker process + job handler registry
  tests/              node:test suite (retry math, atomic claiming, lifecycle)
  scripts/seed.js     demo data generator
frontend/             React (Vite) dashboard
docs/                 architecture, ER diagram, API docs, design decisions
```

## Requirements

- Node.js **22.5+** (uses the built-in `node:sqlite` module — no
  database server or native module compilation required)

## Setup

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
npm run seed        # creates a demo user, project, queues, and sample jobs
```
The seed script prints a demo project API key — copy it into `.env` as
`WORKER_API_KEY`.

```bash
npm start            # API server on http://localhost:4000
```

In a second terminal:
```bash
npm run worker       # starts a worker process that polls & executes jobs
```

Demo login: `demo@example.com` / `password123`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev           # http://localhost:5173, proxies API calls to :4000
```
(`.env` sets `VITE_API_BASE_URL=http://localhost:4000` — change it if
the API runs elsewhere.)

### 3. Run the tests

```bash
cd backend
npm test
```
Covers: retry backoff math (fixed/linear/exponential + jitter bounds),
atomic claiming under concurrent workers (including paused-queue and
not-yet-eligible cases), and the full retry → dead-letter lifecycle
including idempotency-key deduplication.

## Using the system

1. Register (or use the seeded demo account) — this creates your first
   organization + project automatically.
2. From **Queues**, create a queue with a priority, concurrency limit,
   and retry policy.
3. From a queue's detail page, **Submit Job** — pick a mode
   (immediate/delayed/scheduled/recurring/batch) and a `type`. Built-in
   handler types: `echo`, `sleep`, `http_request`, `send_email` (stub),
   `fail_test` (always fails — useful for watching retry/backoff/DLQ
   happen live).
4. Start a worker (`npm run worker` in `backend/`) and watch jobs move
   through **queued → claimed → running → completed** on the dashboard,
   which polls every few seconds.
5. Force a few `fail_test` jobs through their retry budget to see them
   land in **Dead Letter Queue**, and use its "retry" action (via the
   job detail page) to requeue one.

## Adding a new job type

Job execution is pluggable. In `backend/src/worker/jobHandlers.js`:
```js
registerHandler('resize_image', async (payload) => {
  // ... do the work ...
  return { resizedUrl: '...' };
});
```
No server-side changes are needed — the API already accepts any string
as a job's `type`; it's purely up to the worker to know how to handle it.

## Notes on scope

This submission favors depth over breadth per the assignment's stated
evaluation priorities: system architecture, database design, backend
engineering, and reliability/concurrency are fully built out and
tested; bonus features (workflow dependencies, rate limiting, event-driven
execution) are intentionally left out and discussed in
[Design Decisions §9](docs/DESIGN_DECISIONS.md#9-whats-explicitly-out-of-scope-for-this-submission),
alongside what implementing them next would look like. Role-based
access control is implemented as one bonus that *is* included.
